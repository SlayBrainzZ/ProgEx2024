package CommonInterface;

public interface CRUDInterface {
	public void Insert();
	public void Update();
	public void Delete();
	public void Read();
	
}
