package BusinessLayer;

public class SendEmail {

	
}
