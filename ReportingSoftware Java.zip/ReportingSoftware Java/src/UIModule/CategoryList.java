package UIModule;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import ExceptionHandling.ExceptionMaster;

import java.sql.*;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Dimension;
import javax.swing.ImageIcon;
public class CategoryList extends JFrame {
	DefaultTableModel objTableModel;
	private JPanel contentPane;
	private JTable table;
	
	String[] Ctgs = new String[] {};
	int[] IDs = new int[] {};
	int[] sortedIDs = new int[] {};
	int ArrLen = 0;
	String connectionUrl = "jdbc:sqlserver://LAPTOP-9HEOT6R2\\SQLEXPRESS01;databaseName=StockManagement;user=Devansh;password=devansh21";
	Connection con;
	
	ExceptionMaster obj = new ExceptionMaster();
	private JLabel lblNewLabel;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CategoryList frame = new CategoryList();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CategoryList() {
		
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			con = DriverManager.getConnection(connectionUrl);
			
			
		}
		catch(Exception ex) {
			obj.InsertException(ex.getMessage(), "CategoryList", "Constructor");
			
		}
		
		
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(-4, 60, 1545, 800);
		contentPane = new JPanel();
		contentPane.setBackground(Color.CYAN);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		objTableModel = new DefaultTableModel();
		objTableModel.addColumn("ID");
		objTableModel.addColumn("Category");
		getIDs();
		
		
		getData();
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(494, 214, 526, 435);
		contentPane.add(scrollPane);
		
		table = new JTable(objTableModel);
		table.setRowHeight(30);
		table.setBackground(Color.WHITE);
		table.setFont(new Font("Tahoma", Font.PLAIN, 20));
		scrollPane.setViewportView(table);
		
		lblNewLabel = new JLabel("Category List");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel.setBounds(656, 162, 178, 42);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon(CategoryList.class.getResource("/BackgroundImage/aqua BG.png")));
		lblNewLabel_1.setBounds(0, 0, 1545, 810);
		contentPane.add(lblNewLabel_1);
		quick(IDs, 0, ArrLen-1);
		getData();
		
		
	}
	
	public void getIDs() {
		
		try {
			
			CallableStatement stmt = con.prepareCall("{call Proc_CategoryMaster_Read}", ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			ResultSet rs = stmt.executeQuery();
			rs.last();
			ArrLen = rs.getRow();
			
			rs.beforeFirst();
			IDs = new int[ArrLen];
			int i=0;
			while(rs.next()) {
				IDs[i] = rs.getInt("CategoryID");
				i++;
			}
			
			
			
			
		}
		catch(Exception e){
			
			obj.InsertException(e.getMessage(), "CategoryList", "getCtg");
			JOptionPane.showMessageDialog(null, "Oops! An error occured. Please try again later");
		}
		
	}
	
	
	public int sortCtg(int IDs[], int first, int last  ) {
		
		int pivot = IDs[last]; // pivot element  
		    int i = (first - 1);  
		  
		    for (int j = first; j <= last- 1; j++)  
		    {  
		        
		        if (IDs[j] > pivot)  
		        {  
		            i++; 
		            int t = IDs[i];  
		            IDs[i] = IDs[j];  
		            IDs[j] = t;  
		        }  
		    }  
		    int t = IDs[i+1];  
		    IDs[i+1] = IDs[last];  
		    IDs[last] = t;  
		    return (i + 1);  
		
	}
	
	void quick(int a[], int first, int last)   
	{  
	    if (first < last)  
	    {  
	        int p_Index = sortCtg(a, first, last);  
	        quick(a, first, p_Index - 1);  
	        quick(a, p_Index + 1, last);  
	    }  
	}  
	
	
	
	public void getData() {
		objTableModel.setRowCount(0);
		try {
			
			CallableStatement stmt = con.prepareCall("{call Proc_CategoryMaster_Read}");
			ResultSet rs = stmt.executeQuery();
			int i=0;
			
			while(rs.next()) {
				objTableModel.insertRow(0, new Object[] { IDs[i]  , rs.getString("CategoryName") } );
				i++;
			}
			
		}
		catch(Exception e) {
			obj.InsertException(e.getMessage(), "CategoryList", "getData");
		}
		
	}
}
