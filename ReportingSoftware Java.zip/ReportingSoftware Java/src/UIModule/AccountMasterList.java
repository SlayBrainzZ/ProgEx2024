package UIModule;
import java.awt.BorderLayout;

import java.awt.EventQueue;


import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import ExceptionHandling.ExceptionMaster;

import javax.swing.JTable;
import javax.swing.JLabel;
import java.awt.Font;
import java.sql.*;
import javax.swing.JScrollPane;
import javax.swing.ImageIcon;
public class AccountMasterList extends JFrame {
	String connectionUrl = "jdbc:sqlserver://LAPTOP-9HEOT6R2\\SQLEXPRESS01;databaseName=StockManagement;user=Devansh;password=devansh21";
	Connection con;
	
	DefaultTableModel objTableModel; 
	private JPanel contentPane;
	private JTable table;
	JLabel lblMsg;
	ExceptionMaster objEx = new ExceptionMaster();
	private JScrollPane scrollPane;
	private JLabel lblNewLabel;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AccountMasterList frame = new AccountMasterList();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AccountMasterList() {
		
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			con = DriverManager.getConnection(connectionUrl);
			
			
		}
		catch(Exception ex) {
			objEx.InsertException(ex.getMessage(), "AccountMasterList", "Constructor");
			
		}
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(-1, 60, 1545, 800);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		lblMsg = new JLabel("");
		lblMsg.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblMsg.setBounds(248, 52, 1070, 36);
		contentPane.add(lblMsg);
		
		
		
		objTableModel = new DefaultTableModel();
		objTableModel.addColumn("ID");
		objTableModel.addColumn("Name");
		objTableModel.addColumn("City");
		objTableModel.addColumn("Email ID");
		objTableModel.addColumn("Phone Number");
		objTableModel.addColumn("Balance Amount");
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(248, 150, 1022, 185);
		contentPane.add(scrollPane);
		
		table = new JTable(objTableModel);
		scrollPane.setViewportView(table);
		
		lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(AccountMasterList.class.getResource("/BackgroundImage/BG 2.jpg")));
		lblNewLabel.setBounds(0, 0, 1545, 800);
		contentPane.add(lblNewLabel);
		
		getData();
	}
	
	public void getData() {
		
		try {
			
			CallableStatement stmt = con.prepareCall("{call Proc_AccountMaster_Get}");
			
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()) {
				
				objTableModel.insertRow(0, new Object[] {rs.getInt("AccountID"), rs.getString("Name"), rs.getString("City"), rs.getString("EmailID"), rs.getString("Phone_Number"),  rs.getDouble("Balance_Amount")   }  );
				
				
			}
			
			
		}
		catch(Exception e) {
			
			objEx.InsertException(e.getMessage(), "AccountMasterList", "Constructor");
			
		}
		
	}
}
