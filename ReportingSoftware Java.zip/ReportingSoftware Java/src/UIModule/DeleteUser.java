package UIModule;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;

import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;
import java.sql.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import javax.swing.border.MatteBorder;

import ExceptionHandling.ExceptionMaster;

import java.awt.Color;
import javax.swing.border.LineBorder;
public class DeleteUser extends JFrame {
	String connectionUrl = "jdbc:sqlserver://LAPTOP-9HEOT6R2\\SQLEXPRESS01;databaseName=StockManagement;user=Devansh;password=devansh21";
	Connection con;
	String[] Users = new String[] {};
	
	ExceptionMaster obj = new ExceptionMaster();
	
	private JPanel contentPane;
	private JTextField txtName;
	private JTextField txtPhone;
	private JTextField txtEmail;
	private JTextField txtAddress;
	private JPasswordField pwdPass;
	JComboBox comboBox;
	JLabel lblMsg;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DeleteUser frame = new DeleteUser();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DeleteUser() {
		
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			con = DriverManager.getConnection(connectionUrl);
			
			
		}
		catch(Exception ex) {
			
			obj.InsertException(ex.getMessage(), "DeleteUser", "Constructor");
			
			lblMsg.setText(ex.getMessage());
			
		}
		
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(-5, 60, 1545, 800);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(176, 224, 230));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel.setBounds(364, 188, 894, 324);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Username");
		lblNewLabel.setFont(new Font("Calibri", Font.BOLD, 25));
		lblNewLabel.setBounds(33, 98, 123, 31);
		panel.add(lblNewLabel);
		
		comboBox = new JComboBox();
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String User = (String) comboBox.getSelectedItem();
				getUserDetails(User);
				
			}
		});
		comboBox.setBounds(210, 98, 207, 31);
		panel.add(comboBox);
		
		JLabel lblName = new JLabel("Name");
		lblName.setFont(new Font("Calibri", Font.BOLD, 25));
		lblName.setBounds(33, 191, 70, 31);
		panel.add(lblName);
		
		txtName = new JTextField();
		txtName.setFont(new Font("Tahoma", Font.BOLD, 13));
		txtName.setEditable(false);
		txtName.setBounds(208, 191, 207, 31);
		panel.add(txtName);
		txtName.setColumns(10);
		
		txtPhone = new JTextField();
		txtPhone.setFont(new Font("Tahoma", Font.BOLD, 13));
		txtPhone.setEditable(false);
		txtPhone.setColumns(10);
		txtPhone.setBounds(639, 98, 207, 31);
		panel.add(txtPhone);
		
		JLabel lblPhoneNumber = new JLabel("Phone Number");
		lblPhoneNumber.setFont(new Font("Calibri", Font.BOLD, 25));
		lblPhoneNumber.setBounds(464, 98, 164, 31);
		panel.add(lblPhoneNumber);
		
		txtEmail = new JTextField();
		txtEmail.setFont(new Font("Tahoma", Font.BOLD, 13));
		txtEmail.setEditable(false);
		txtEmail.setColumns(10);
		txtEmail.setBounds(639, 145, 207, 31);
		panel.add(txtEmail);
		
		JLabel lblEmailId = new JLabel("Email ID");
		lblEmailId.setFont(new Font("Calibri", Font.BOLD, 25));
		lblEmailId.setBounds(464, 145, 164, 31);
		panel.add(lblEmailId);
		
		txtAddress = new JTextField();
		txtAddress.setFont(new Font("Tahoma", Font.BOLD, 13));
		txtAddress.setEditable(false);
		txtAddress.setColumns(10);
		txtAddress.setBounds(641, 190, 207, 31);
		panel.add(txtAddress);
		
		JLabel lblAddress = new JLabel("Address");
		lblAddress.setFont(new Font("Calibri", Font.BOLD, 25));
		lblAddress.setBounds(466, 190, 164, 31);
		panel.add(lblAddress);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setFont(new Font("Calibri", Font.BOLD, 25));
		lblPassword.setBounds(33, 144, 164, 31);
		panel.add(lblPassword);
		
		pwdPass = new JPasswordField();
		pwdPass.setFont(new Font("Tahoma", Font.BOLD, 13));
		pwdPass.setBounds(208, 144, 207, 31);
		panel.add(pwdPass);
		
		JLabel lblNewLabel_1 = new JLabel("Delete User");
		lblNewLabel_1.setBounds(356, 10, 158, 36);
		panel.add(lblNewLabel_1);
		lblNewLabel_1.setFont(new Font("Calibri", Font.BOLD, 29));
		
		JButton btnDel = new JButton("Delete");
		btnDel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				String Pass = pwdPass.getText();
				String out = deleteUser(Pass);
				
				if(out.equals("1")) {
					
					JOptionPane.showMessageDialog(panel, "User successfully deleted");
					txtName.setText("");
					txtEmail.setText("");
					txtPhone.setText("");
					pwdPass.setText("");
					
				}
				else {
					JOptionPane.showMessageDialog(panel, "Wrong password.");
				}
				
				
			}
		});
		btnDel.setVerticalAlignment(SwingConstants.TOP);
		btnDel.setFont(new Font("Calibri", Font.BOLD, 25));
		btnDel.setBounds(356, 260, 180, 36);
		panel.add(btnDel);
		
		JLabel lblPanelBG = new JLabel("");
		lblPanelBG.setIcon(new ImageIcon("C:\\Users\\devan\\Downloads\\bg blue.jpg"));
		lblPanelBG.setBounds(0, 0, 894, 324);
		panel.add(lblPanelBG);
		
		lblMsg = new JLabel("\r\n");
		lblMsg.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblMsg.setBounds(364, 123, 894, 41);
		contentPane.add(lblMsg);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setIcon(new ImageIcon("C:\\Users\\devan\\Downloads\\BG.png"));
		lblNewLabel_2.setBounds(0, 0, 1545, 875);
		contentPane.add(lblNewLabel_2);
		populateCmbBox();
	}
	
	public void populateCmbBox() {
		int Index = 0;
		int ArrLen = 0;
		
		try {
			
			CallableStatement stmt = con.prepareCall("{call Proc_UserMaster_GetUsers}");
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				if(Index==0) {
					ArrLen = rs.getInt("RowCount");
					Users = new String[ArrLen];
					
				}
				Users[Index] = rs.getString("Username");
				Index++;
				
				comboBox.removeAllItems();
				
				for(int i=0;i<ArrLen;i++) {
					comboBox.addItem(Users[i]);
				}
			}
			
			
		}
		
		catch(Exception e){
			obj.InsertException(e.getMessage(), "DeleteUser", "populateCmbBox");
			lblMsg.setText("Error in populateCmbBox: "+ e.getMessage());
		}
		
	}
	
	public void getUserDetails(String Username) {
		try {
			CallableStatement stmt = con.prepareCall("{call Proc_UserMaster_GetDetails(?)}");
			stmt.setString(1, Username);
			
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()) {
				txtName.setText(rs.getString("Name"));
				txtEmail.setText(rs.getString("Email_ID"));
				txtPhone.setText(rs.getString("Phone_Number"));
				txtAddress.setText(rs.getString("Address"));
				
			}
			stmt.close();
			
			
			
		}
		catch(Exception e) {
			obj.InsertException(e.getMessage(), "DeleteUser", "getUserDetails");
			lblMsg.setText("Error in getUserDetails: "+ e.getMessage());
		}
	}
	
	public String deleteUser(String Pass) {
		String out = "-1";
		
		try {
			
			CallableStatement stmt = con.prepareCall("{call Proc_UserMaster_Delete(?)}");
			
			stmt.setString(1, Pass);
			
			ResultSet rs = stmt.executeQuery();
			rs.next();
			out = rs.getString("out");
			
			stmt.close();
			populateCmbBox();
			
		}
		catch(Exception e) {
			obj.InsertException(e.getMessage(), "DeleteUser", "deleteUser");
			lblMsg.setText("Error in deleteUser: "+ e.getMessage());
		}
		
		return out;
	}
}
