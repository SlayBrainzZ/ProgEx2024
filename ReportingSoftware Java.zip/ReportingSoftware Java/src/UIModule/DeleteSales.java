package UIModule;

import java.awt.BorderLayout;
import java.awt.event.ItemEvent;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.Color;
import javax.swing.border.LineBorder;

import BusinessLayer.SalesBusiness;
import CommonInterface.CRUDInterface;
import ExceptionHandling.ExceptionMaster;

import java.awt.event.ActionListener;
import java.io.Console;
import java.awt.event.ActionEvent;
import java.sql.*;
import javax.swing.JComboBox;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import javax.swing.ImageIcon;
import java.util.*;

public class DeleteSales extends JFrame implements ItemListener, CRUDInterface {
	String connectionUrl = "jdbc:sqlserver://LAPTOP-9HEOT6R2\\SQLEXPRESS01;databaseName=StockManagement;user=Devansh;password=devansh21";
	Connection con;
	private JPanel contentPane;
	JLabel lblMsg;
	private JTextField txtBalAmt;
	private JTextField txtDate;
	JComboBox cmbBoxCusName;
	JComboBox cmbBoxSalesID ;
	
	SalesBusiness objSales = new SalesBusiness();
	
	Integer[] SalesID = new Integer[] {};
	
	String[] CusNames = new String[] {};
	private JTextField txtItems;

	ExceptionMaster obj = new ExceptionMaster();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DeleteSales frame = new DeleteSales();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DeleteSales() {
		
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			con = DriverManager.getConnection(connectionUrl);
			
			
		}
		catch(Exception ex) {
			obj.InsertException(ex.getMessage(), "DeleteSales", "constructor");
			lblMsg.setText(ex.getMessage());
		}
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(-5, 60, 1545, 800);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		lblMsg = new JLabel("");
		lblMsg.setForeground(Color.PINK);
		lblMsg.setFont(new Font("Dubai", Font.BOLD, 24));
		lblMsg.setBounds(0, 170, 1531, 36);
		contentPane.add(lblMsg);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel.setBackground(new Color(175, 238, 238));
		panel.setBounds(611, 216, 404, 431);
		contentPane.add(panel);
		panel.setLayout(null);
		
		cmbBoxCusName = new JComboBox();
		cmbBoxCusName.addItemListener(this);
		
		cmbBoxCusName.setBounds(195, 89, 169, 28);
		panel.add(cmbBoxCusName);
		
		JLabel lblNewLabel = new JLabel("Delete Sales");
		lblNewLabel.setFont(new Font("Calibri", Font.BOLD, 25));
		lblNewLabel.setBounds(129, 23, 152, 31);
		panel.add(lblNewLabel);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Delete();
				JOptionPane.showMessageDialog(null, "Sales successfully deleted");
				
			}
		});
		btnDelete.setBackground(Color.LIGHT_GRAY);
		btnDelete.setVerticalAlignment(SwingConstants.TOP);
		btnDelete.setFont(new Font("Calibri", Font.BOLD, 20));
		btnDelete.setBounds(129, 371, 144, 31);
		panel.add(btnDelete);
		
		JLabel lblCustomerName = new JLabel("Customer Name");
		lblCustomerName.setFont(new Font("Calibri", Font.BOLD, 20));
		lblCustomerName.setBounds(33, 85, 152, 31);
		panel.add(lblCustomerName);
		
		txtBalAmt = new JTextField();
		txtBalAmt.setEditable(false);
		txtBalAmt.setColumns(10);
		txtBalAmt.setBounds(195, 188, 169, 28);
		panel.add(txtBalAmt);
		
		JLabel lblAmount = new JLabel("Amount");
		lblAmount.setFont(new Font("Calibri", Font.BOLD, 20));
		lblAmount.setBounds(33, 189, 152, 31);
		panel.add(lblAmount);
		
		txtDate = new JTextField();
		txtDate.setEditable(false);
		txtDate.setColumns(10);
		txtDate.setBounds(195, 310, 169, 28);
		panel.add(txtDate);
		
		JLabel lblTransactionDate = new JLabel("Transaction Date");
		lblTransactionDate.setFont(new Font("Calibri", Font.BOLD, 20));
		lblTransactionDate.setBounds(33, 311, 152, 31);
		panel.add(lblTransactionDate);
		
		JLabel lblSalesId = new JLabel("Sales ID");
		lblSalesId.setFont(new Font("Calibri", Font.BOLD, 20));
		lblSalesId.setBounds(33, 141, 152, 31);
		panel.add(lblSalesId);
		
		cmbBoxSalesID = new JComboBox();
		cmbBoxSalesID.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(cmbBoxSalesID.getSelectedItem() != null) {
					int SalesID = (int) cmbBoxSalesID.getSelectedItem();
					GetSalesDetails(SalesID);
					
				}

			}
		});
		cmbBoxSalesID.setBounds(195, 141, 169, 28);
		panel.add(cmbBoxSalesID);
		
		JLabel lblItemsBought = new JLabel("Items Bought");
		lblItemsBought.setFont(new Font("Calibri", Font.BOLD, 20));
		lblItemsBought.setBounds(33, 248, 152, 31);
		panel.add(lblItemsBought);
		
		txtItems = new JTextField();
		txtItems.setEditable(false);
		txtItems.setFont(new Font("Dubai", Font.BOLD, 15));
		txtItems.setBounds(195, 249, 169, 28);
		panel.add(txtItems);
		txtItems.setColumns(10);
		txtItems.setOpaque(false);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\devan\\Downloads\\BG.png"));
		lblNewLabel_1.setBounds(0, 0, 1545, 870);
		contentPane.add(lblNewLabel_1);
		
		
		GetCusNamesCmbBox();

		
	}
	
	public void itemStateChanged(ItemEvent item) {
		//lblMsg.setText(cmbBoxSalesID.getSelectedItem().toString());
		String CusName =cmbBoxCusName.getSelectedItem() == null?"":(String) cmbBoxCusName.getSelectedItem();
		
		populateCmbBoxSalesID(CusName);
		
		
		
	}
	
	
	public void GetCusNamesCmbBox() {
		CusNames = objSales.GetCusNamesCmbBox_Delete();
		int Len = CusNames.length;
		
		cmbBoxCusName.removeAllItems();
		
		for(int i=0;i<Len;i++) {
			cmbBoxCusName.addItem(CusNames[i]);
		}
		
	}
	
	public void populateCmbBoxSalesID(String CusName) {
		
		SalesID = objSales.getSalesID_Delete(CusName);
		
		int ArrLen = SalesID.length;
		
		cmbBoxSalesID.removeAllItems();
		
		for(int i =0;i<ArrLen;i++) {
			cmbBoxSalesID.addItem(SalesID[i]);
		}
		
	}
		
		
		
	
	
	public void GetSalesDetails(int SalesID) {
		
		Dictionary SalesDetails = new Hashtable();
		SalesDetails = objSales.GetSalesDetails(SalesID);
		
		txtBalAmt.setText(""+(Double) SalesDetails.get("Amount") );
		txtItems.setText((String) SalesDetails.get("Item") ) ; 
		txtDate.setText((String) SalesDetails.get("Date") );
		
	}
	
	public void Insert() {
	}
	public void Update() {
	}
	public void Read() {
	}
	
	public void Delete() {
		
		String Name = (String) cmbBoxCusName.getSelectedItem();
		objSales.DeleteSales(Name);
		GetCusNamesCmbBox();
	}
	
	
}

