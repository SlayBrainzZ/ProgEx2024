package UIModule;

import java.awt.BorderLayout;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import BusinessLayer.InvoiceBusiness;
import ExceptionHandling.ExceptionMaster;

import java.io.*;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.util.*;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.Color;
import javax.swing.ImageIcon;
public class CreateInvoice extends JFrame {
	
	ExceptionMaster objEx = new ExceptionMaster();
	
	DefaultTableModel objTableModel = new DefaultTableModel();
	
	Dictionary Details = new Hashtable();
	
	Dictionary SalesDetails = new Hashtable();
	
	InvoiceBusiness objInvoice = new InvoiceBusiness();

	JComboBox cmbBoxAccID;
	JComboBox cmbBoxSalesID;
	JComboBox cmbBoxTranID;
	
	JLabel lblMsg;
	
	private JPanel contentPane;
	private JLabel lblNewLabel;
	private JLabel lblSalesid;
	private JLabel lblTransactionId;
	private JTable table;
	private JTextField txtName;
	private JTextField txtAdd1;
	private JTextField txtAdd2;
	private JTextField txtAdd3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CreateInvoice frame = new CreateInvoice();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CreateInvoice() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(-5, 60, 1545, 800);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 206, 209));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("Create Invoice");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				FileWriter();
				JOptionPane.showMessageDialog(null, "Invoice created");
			}
		});
		
		lblMsg = new JLabel("");
		lblMsg.setBounds(250, 140, 179, 41);
		contentPane.add(lblMsg);
		btnNewButton.setBounds(747, 706, 118, 34);
		contentPane.add(btnNewButton);
		
		cmbBoxAccID = new JComboBox();
		cmbBoxAccID.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String var = (String) cmbBoxAccID.getSelectedItem();
				
				int AccID = Integer.parseInt(var) ;
				
				
				
				getSalesID(AccID);
				getDetails(AccID);
				getArrDetails(AccID);
			}
		});
		cmbBoxAccID.setBounds(548, 154, 151, 27);
		contentPane.add(cmbBoxAccID);
		
		cmbBoxSalesID = new JComboBox();
		cmbBoxSalesID.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				
				if(cmbBoxSalesID.getSelectedItem() != null) {
				
					int SalesID = Integer.parseInt(cmbBoxSalesID.getSelectedItem().toString()) ;
					getTranID(SalesID);
				}
		
			}
		});
		cmbBoxSalesID.setBounds(747, 154, 151, 27);
		contentPane.add(cmbBoxSalesID);
		
		cmbBoxTranID = new JComboBox();
		cmbBoxTranID.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				getTableData();
				
			}
		});
		cmbBoxTranID.setBounds(951, 154, 151, 27);
		contentPane.add(cmbBoxTranID);
		
		lblNewLabel = new JLabel("AccountID");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 19));
		lblNewLabel.setBounds(548, 118, 118, 26);
		contentPane.add(lblNewLabel);
		
		lblSalesid = new JLabel("SalesID");
		lblSalesid.setFont(new Font("Tahoma", Font.PLAIN, 19));
		lblSalesid.setBounds(747, 118, 118, 26);
		contentPane.add(lblSalesid);
		
		lblTransactionId = new JLabel("Transaction ID");
		lblTransactionId.setFont(new Font("Tahoma", Font.PLAIN, 19));
		lblTransactionId.setBounds(950, 118, 152, 26);
		contentPane.add(lblTransactionId);
		
		objTableModel.addColumn("Item");
		objTableModel.addColumn("Unit Price");
		objTableModel.addColumn("Quantity");
		objTableModel.addColumn("Total Amount");
		objTableModel.addColumn("Order Date");
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(548, 413, 555, 131);
		contentPane.add(scrollPane);
		
		table = new JTable(objTableModel);
		scrollPane.setViewportView(table);
		
		JPanel panel = new JPanel();
		panel.setBounds(499, 210, 648, 172);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Customer Details");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(235, 10, 173, 22);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Address Line 1");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_2.setBounds(35, 104, 130, 22);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_2_1 = new JLabel("Address Line 2");
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_2_1.setBounds(353, 62, 130, 22);
		panel.add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_2_2 = new JLabel("Address Line 3");
		lblNewLabel_2_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_2_2.setBounds(352, 104, 130, 22);
		panel.add(lblNewLabel_2_2);
		
		JLabel lblNewLabel_2_3 = new JLabel("Customer Name");
		lblNewLabel_2_3.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_2_3.setBounds(32, 61, 153, 22);
		panel.add(lblNewLabel_2_3);
		
		txtName = new JTextField();
		txtName.setEditable(false);
		txtName.setBounds(181, 61, 143, 27);
		panel.add(txtName);
		txtName.setColumns(10);
		
		txtAdd1 = new JTextField();
		txtAdd1.setEditable(false);
		txtAdd1.setColumns(10);
		txtAdd1.setBounds(181, 101, 143, 27);
		panel.add(txtAdd1);
		
		txtAdd2 = new JTextField();
		txtAdd2.setEditable(false);
		txtAdd2.setColumns(10);
		txtAdd2.setBounds(495, 61, 143, 27);
		panel.add(txtAdd2);
		
		txtAdd3 = new JTextField();
		txtAdd3.setEditable(false);
		txtAdd3.setColumns(10);
		txtAdd3.setBounds(495, 99, 143, 27);
		panel.add(txtAdd3);
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(new ImageIcon(CreateInvoice.class.getResource("/BackgroundImage/aqua BG.png")));
		lblNewLabel_3.setBounds(0, 0, 1545, 800);
		contentPane.add(lblNewLabel_3);
		
		getAccIDs();
		
	}
	
	public void getAccIDs() {
		String[] AccId = new String[] {};
		
		AccId = objInvoice.getAccIDs();
		int Len = AccId.length;
		
		for(int i=0;i<Len;i++) {
			cmbBoxAccID.addItem(AccId[i]);
			
			
		}
	}
	
	public void getSalesID(int AccID) {
		
		try {
			cmbBoxSalesID.removeAllItems();
			int[] SalesID = new int[] {} ;
			
			
			SalesID = objInvoice.getSalesID(AccID);
			
			int Len = SalesID.length;

			
			for(int i=0;i<Len;i++) {
				
				cmbBoxSalesID.addItem(SalesID[i]);
			}
		}
		catch(Exception Ex) {
			JOptionPane.showMessageDialog(null, Ex);
		}

	}
	
	public void getTranID(int SalesID) {
		cmbBoxTranID.removeAllItems();
		SalesDetails = objInvoice.getTranDetails(SalesID);
		
		cmbBoxTranID.addItem(SalesDetails.get("TranID"));
		
		
	}
	
	
	
	public void FileWriter() {
		
		int AccID = Integer.parseInt((String) cmbBoxAccID.getSelectedItem()) ;
				

		try {
			String ID = cmbBoxSalesID.getSelectedItem().toString();
			int SalesID = Integer.parseInt(ID);
			FileWriter objFW = new FileWriter("C://School/Invoice.txt");
			
			
			objFW.write(objInvoice.CompanyInfo(SalesID, AccID, Details.get("InvoiceDate"),
			Details.get("Name"), Details.get("Add1"), Details.get("Add2"), Details.get("Add3"), 
			SalesDetails.get("OrderDate"), SalesDetails.get("Rate"), SalesDetails.get("Qtty"), 
			SalesDetails.get("Item"), SalesDetails.get("Amt") ).toString());
			
			objFW.close();
			
		}
		
		catch(Exception Ex) {
			objEx.InsertException(Ex.getMessage(), "CreateInvoice" , "FileWriter");
			JOptionPane.showMessageDialog(null, "FileWriter: " +Ex);
			
		}
		
	}
	
	public void getDetails(int AccID) {

		Details = objInvoice.getAddress1(AccID);
		txtName.setText(""+Details.get("Name"));
		txtAdd1.setText(""+Details.get("Add1"));
		txtAdd2.setText(""+Details.get("Add2"));
		txtAdd3.setText(""+Details.get("Add3"));
		
		
		
	}
	
	public void getArrDetails(int AccID) {
		String[][] ArrDetails = new String[][] {};
		
		ArrDetails = objInvoice.getDetails2DArr(AccID);
		int Len= ArrDetails.length;
		
		for(int i=0;i<Len;i++) {
			for(int j=0;j<5;j++) {
				
				if(j==0) {
					 txtName.setText(ArrDetails[i][j]);;
				}
				else if(j==1) {
					txtAdd1.setText(ArrDetails[i][j]);
				}
				else if(j==2) {
					txtAdd2.setText(ArrDetails[i][j]);
				}
				else if(j==3) {
					txtAdd3.setText(ArrDetails[i][j]);
				}
				
				
				
				
			}
		}
		
		
		
	}
	
	public void getTableData() {
		
		int Rows = objTableModel.getRowCount();
		
		for(int i=0;i<Rows;i++) {
			objTableModel.removeRow(i);
		}
		
		
		
		objTableModel.insertRow(0, new Object[] {SalesDetails.get("Item"), SalesDetails.get("Rate"), SalesDetails.get("Qtty"), SalesDetails.get("Amt"), SalesDetails.get("OrderDate") } );
		
	}
}
