package UIModule;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import BusinessLayer.MonthlyRevReportBusiness;

import javax.swing.JTable;
import javax.swing.JComboBox;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MonthlyRevenueReport extends JFrame {

	private JPanel contentPane;
	private JTable table;

	MonthlyRevReportBusiness objReport = new MonthlyRevReportBusiness();
	JComboBox comboBox;
	DefaultTableModel objTableModel = new DefaultTableModel();
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MonthlyRevenueReport frame = new MonthlyRevenueReport();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MonthlyRevenueReport() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(-5, 60, 1545, 800);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		objTableModel.addColumn("Month");
		objTableModel.addColumn("Revenue");
		
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(697, 294, 616, 276);
		contentPane.add(scrollPane);
		
		table = new JTable(objTableModel);
		scrollPane.setViewportView(table);
		
		comboBox = new JComboBox();
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String Month = (String) comboBox.getSelectedItem();
				
				getRevenue(Month);
				
			}
		});
		comboBox.setBounds(414, 294, 170, 31);
		contentPane.add(comboBox);
		
		populateComboBox();
	}
	
	public void populateComboBox() {
		
		String[] Months = new String[] {};
		Months = objReport.getMonths();
		int Len = Months.length;
		
		for(int i=0;i<Len;i++) {
			
			comboBox.addItem(Months[i]);
			
		}

	}
	
	public void getRevenue(String Month) {
		double Rev = objReport.getRevenue(Month);
		objTableModel.setRowCount(0);
		objTableModel.insertRow(0, new Object[] {Month, Rev});
		
	}
}
