package UIModule;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.DefaultComboBoxModel;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;
import javax.swing.UIManager;
import java.awt.Color;
import javax.swing.border.LineBorder;

import BusinessLayer.ItemBusiness;
import CommonInterface.CRUDInterface;
import ExceptionHandling.ExceptionMaster;

import java.sql.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.ImageIcon;
import java.util.*;

public class DeleteItem extends JFrame implements CRUDInterface {
	
	JLabel lblMsg;
	
	private JPanel contentPane;
	private JTextField txtSKU;
	private JTextField txtDesc;
	String[] Items = new String[] {};
	JComboBox comboBox;
	
	ItemBusiness objItem = new ItemBusiness();
	ExceptionMaster obj= new ExceptionMaster();
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DeleteItem frame = new DeleteItem();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DeleteItem() {
		
	
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(-5, 60, 1545, 800);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel.setBackground(Color.WHITE);
		panel.setBounds(603, 260, 400, 293);
		contentPane.add(panel);
		panel.setLayout(null);
		
		
		
		JLabel lblNewLabel = new JLabel("Delete Item");
		lblNewLabel.setBounds(134, 10, 132, 29);
		panel.add(lblNewLabel);
		lblNewLabel.setFont(new Font("Calibri", Font.BOLD, 26));
		
		txtDesc = new JTextField();
		txtDesc.setBounds(149, 161, 198, 28);
		panel.add(txtDesc);
		txtDesc.setEditable(false);
		txtDesc.setColumns(10);
		
		JLabel lblNewLabel_1_3_3 = new JLabel("Description");
		lblNewLabel_1_3_3.setBounds(41, 160, 101, 30);
		panel.add(lblNewLabel_1_3_3);
		lblNewLabel_1_3_3.setFont(new Font("Calibri", Font.BOLD, 20));
		
		JButton btnNewButton = new JButton("Delete");
		btnNewButton.setBounds(114, 237, 171, 30);
		panel.add(btnNewButton);
		btnNewButton.setBackground(new Color(102, 204, 204));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {				
				Delete();
				JOptionPane.showMessageDialog(btnNewButton, "Item Successfully deleted");
			}
		});
		btnNewButton.setVerticalAlignment(SwingConstants.TOP);
		btnNewButton.setFont(new Font("Calibri", Font.BOLD, 20));
		
		
		
		txtSKU = new JTextField();
		txtSKU.setBounds(150, 111, 198, 28);
		panel.add(txtSKU);
		txtSKU.setEditable(false);
		txtSKU.setColumns(10);
		
		comboBox = new JComboBox();
		comboBox.setBounds(150, 62, 196, 28);
		panel.add(comboBox);
		
		JLabel lblNewLabel_1_3_1 = new JLabel("Item name");
		lblNewLabel_1_3_1.setBounds(41, 62, 101, 23);
		panel.add(lblNewLabel_1_3_1);
		lblNewLabel_1_3_1.setFont(new Font("Calibri", Font.BOLD, 20));
		
		JLabel lblNewLabel_1_3_2 = new JLabel("SKU Code");
		lblNewLabel_1_3_2.setBounds(41, 110, 101, 30);
		panel.add(lblNewLabel_1_3_2);
		lblNewLabel_1_3_2.setFont(new Font("Calibri", Font.BOLD, 20));
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setBounds(0, 0, 400, 293);
		panel.add(lblNewLabel_2);
		lblNewLabel_2.setIcon(new ImageIcon("C:\\Users\\devan\\Pictures\\GradientBG.jpg"));
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String ItemName = (String) comboBox.getSelectedItem();
				GetItemDetails(ItemName);
				
			}
		});
		
		lblMsg = new JLabel("");
		lblMsg.setForeground(Color.RED);
		lblMsg.setFont(new Font("Arial", Font.BOLD, 22));
		lblMsg.setBounds(603, 197, 690, 39);
		contentPane.add(lblMsg);
		
		JLabel lblBG = new JLabel("");
		lblBG.setIcon(new ImageIcon("C:\\Users\\devan\\Downloads\\GradBG1 (3).jpg"));
		lblBG.setBounds(0, 0, 1545, 870);
		contentPane.add(lblBG);
		
		populateComboBox();
		
	}
	
	public void populateComboBox() {
		comboBox.removeAllItems();
		Items = objItem.populateComboBox_Delete();
		int ArrLen = Items.length;
		
		for(int i=0;i<ArrLen;i++) {
			comboBox.addItem(Items[i]);
		}
		
	}
	
	public void GetItemDetails(String ItemName) {
		
		Dictionary ItemDetails = new Hashtable();
		
		ItemDetails = objItem.GetItemDetails(ItemName);
		
		txtSKU.setText((String) ItemDetails.get("SKU"));
		txtDesc.setText((String) ItemDetails.get("Desc"));
		
	
		
	}
	
	public void Update() {
		
	}
	public void Insert() {
		
	}
	public void Read() {
		
	}
	
	public void Delete() {
		
		String itemName = (String) comboBox.getSelectedItem();
		objItem.DeleteFromDB(itemName);
		populateComboBox();
		
	}
	
	
}
