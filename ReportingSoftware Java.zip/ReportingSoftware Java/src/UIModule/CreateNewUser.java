package UIModule;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;
import javax.swing.border.LineBorder;

import BusinessLayer.CreateUserBusiness;


import javax.swing.JPasswordField;
import java.sql.*;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import CommonInterface.CRUDInterface;
import ExceptionHandling.ExceptionMaster;
public class CreateNewUser extends JFrame {
	
	private JPanel contentPane;
	private JTextField txtName;
	private JTextField txtEmail;
	private JTextField txtPhone;
	private JTextField txtUname;
	private JPasswordField pwdPass;
	private JPasswordField pwdConfirmPass;
	
	JLabel lblMsg;
	JLabel lblTest ;
	
	LoginPageNew objLogin = new LoginPageNew();
	
	CreateUserBusiness objUserBusiness = new CreateUserBusiness(); 
	
	ExceptionMaster obj = new ExceptionMaster();
	 
	
	String connectionUrl = "jdbc:sqlserver://LAPTOP-9HEOT6R2\\SQLEXPRESS01;databaseName=StockManagement;user=Devansh;password=devansh21";
	Connection con;
	private JTextField txtAddress;
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CreateNewUser frame = new CreateNewUser();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CreateNewUser() {
		
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			con = DriverManager.getConnection(connectionUrl);
			
			
		}
		catch(Exception ex) {
			obj.InsertException(ex.getMessage(), "CreateNewUser", "constructor");
			lblMsg.setText(ex.getMessage());
			
		}
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(-5, 60, 1545, 810);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Create an account");
		lblNewLabel.setBounds(620, 132, 267, 37);
		contentPane.add(lblNewLabel);
		lblNewLabel.setForeground(Color.BLACK);
		lblNewLabel.setFont(new Font("Calibri", Font.BOLD, 34));
		
		JPanel panel = new JPanel();
		panel.setForeground(new Color(255, 255, 255));
		panel.setBorder(new LineBorder(Color.RED));
		//panel.setBackground(new Color(0,0,0,50));
		panel.setBounds(267, 178, 1022, 400);
		contentPane.add(panel);
		panel.setLayout(null);
		
		txtName = new JTextField();
		txtName.setBounds(244, 75, 262, 28);
		panel.add(txtName);
		txtName.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Name");
		lblNewLabel_1.setForeground(Color.BLACK);
		lblNewLabel_1.setFont(new Font("Calibri", Font.BOLD, 23));
		lblNewLabel_1.setBounds(124, 75, 96, 33);
		panel.add(lblNewLabel_1);
		
		txtEmail = new JTextField();
		txtEmail.setBounds(244, 125, 262, 28);
		panel.add(txtEmail);
		txtEmail.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Email");
		lblNewLabel_2.setForeground(Color.BLACK);
		lblNewLabel_2.setFont(new Font("Calibri", Font.BOLD, 23));
		lblNewLabel_2.setBounds(124, 127, 85, 32);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Phone ");
		lblNewLabel_3.setForeground(Color.BLACK);
		lblNewLabel_3.setFont(new Font("Calibri", Font.BOLD, 23));
		lblNewLabel_3.setBounds(124, 172, 105, 33);
		panel.add(lblNewLabel_3);
		
		txtPhone = new JTextField();
		txtPhone.setBounds(244, 175, 262, 28);
		panel.add(txtPhone);
		txtPhone.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("Password");
		lblNewLabel_4.setForeground(Color.BLACK);
		lblNewLabel_4.setFont(new Font("Calibri", Font.BOLD, 23));
		lblNewLabel_4.setBounds(548, 124, 111, 33);
		panel.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Confirm Password");
		lblNewLabel_5.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel_5.setForeground(Color.BLACK);
		lblNewLabel_5.setFont(new Font("Calibri", Font.BOLD, 23));
		lblNewLabel_5.setBounds(548, 172, 197, 32);
		panel.add(lblNewLabel_5);
		
		JButton btnCreateAcc = new JButton("Create Account");
		btnCreateAcc.setVerticalAlignment(SwingConstants.TOP);
		btnCreateAcc.setBackground(UIManager.getColor("Button.shadow"));
		btnCreateAcc.setFont(new Font("Calibri", Font.BOLD, 24));
		btnCreateAcc.setBounds(292, 304, 214, 38);
		panel.add(btnCreateAcc);
		
		JLabel lblNewLabel_3_1 = new JLabel("Username");
		lblNewLabel_3_1.setForeground(Color.BLACK);
		lblNewLabel_3_1.setFont(new Font("Calibri", Font.BOLD, 23));
		lblNewLabel_3_1.setBounds(548, 80, 145, 28);
		panel.add(lblNewLabel_3_1);
		
		txtUname = new JTextField();
		txtUname.setColumns(10);
		txtUname.setBounds(740, 75, 261, 28);
		panel.add(txtUname);
		
		pwdPass = new JPasswordField();
		pwdPass.setBounds(739, 122, 262, 28);
		panel.add(pwdPass);
		
		pwdConfirmPass = new JPasswordField();
		pwdConfirmPass.setBounds(740, 172, 261, 28);
		panel.add(pwdConfirmPass);
		
		JLabel lblNewLabel_3_2 = new JLabel("Address");
		lblNewLabel_3_2.setForeground(Color.BLACK);
		lblNewLabel_3_2.setFont(new Font("Calibri", Font.BOLD, 23));
		lblNewLabel_3_2.setBounds(124, 224, 96, 36);
		panel.add(lblNewLabel_3_2);
		
		txtAddress = new JTextField();
		txtAddress.setColumns(10);
		txtAddress.setBounds(244, 225, 262, 28);
		panel.add(txtAddress);
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.setVerticalAlignment(SwingConstants.TOP);
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ResetTxtFieldValues();
				lblMsg.setText("");
				
			}
		});
		btnCancel.setBackground(UIManager.getColor("Button.shadow"));
		btnCancel.setFont(new Font("Calibri", Font.BOLD, 24));
		btnCancel.setBounds(591, 304, 214, 35);
		panel.add(btnCancel);
		
		JLabel lblPanelBG = new JLabel("");
		lblPanelBG.setIcon(new ImageIcon(CreateNewUser.class.getResource("/BackgroundImage/BG 2.jpg")));
		lblPanelBG.setBounds(0, 0, 1022, 400);
		panel.add(lblPanelBG);
		
		lblMsg = new JLabel("");
		lblMsg.setForeground(new Color(255, 0, 0));
		lblMsg.setFont(new Font("Tahoma", Font.PLAIN, 19));
		lblMsg.setBounds(267, 62, 701, 60);
		
		contentPane.add(lblMsg);
	
		
		
		lblTest = new JLabel("");
		lblTest.setBounds(92, 328, 260, 60);
		contentPane.add(lblTest);
		
		JLabel lblBackgroung = new JLabel("");
		lblBackgroung.setForeground(new Color(0, 204, 255));
		lblBackgroung.setIcon(new ImageIcon(CreateNewUser.class.getResource("/BackgroundImage/aqua BG.png")));
		lblBackgroung.setBounds(-5, 0, 1545, 830);
		contentPane.add(lblBackgroung);
		
		btnCreateAcc.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Insert();																		
			}
			
		});
	}
	
	public void ResetTxtFieldValues() {
		txtName.setText("");
		txtEmail.setText("");
		txtPhone.setText("");
		txtAddress.setText("");
		txtPhone.setText("");
		txtUname.setText("");
		pwdPass.setText("");
		pwdConfirmPass.setText("");
	}
	
	public void Insert() {
		String Name = txtName.getText();
		String Email= txtEmail.getText();
		String PhNum= txtPhone.getText();
		String Address = txtAddress.getText();
		String Uname= txtUname.getText();
		String Pass = pwdPass.getText();
		String ConfirmPass = pwdConfirmPass.getText();
		String Out = "";
		boolean flag= false;
		
	
	if(Name.length()== 0) {
		lblMsg.setText("Please enter your name");
		flag=true;
	}			
	
	else if(Email.length()== 0) {
		lblMsg.setText("Please enter your email");
		flag=true;
	}
	
	else if(Email.indexOf('@') <1 || Email.indexOf('.') < 1 ) {
		lblMsg.setText("Please enter a valid email");
		flag=true;
	}
	
	else if(PhNum.length()==0 ) {
		lblMsg.setText("Please enter your phone number");
		flag=true;
	}
	
	else if(PhNum.length()>0 && PhNum.length() <10){
		
		lblMsg.setText("Please enter a 10 digit phone number");
		flag = true;
	}
		
		
	else if(Address.length()== 0) {
		lblMsg.setText("Please enter your address");
		flag=true;
	}
	else if(Uname.length()== 0) {
		lblMsg.setText("Please enter your username");
		flag=true;
	}
	else if(Pass.length()==0) {
		lblMsg.setText("Please enter your password");
		flag=true;
	}
	else if(ConfirmPass.length()==0) {
		lblMsg.setText("Please confirm your password");
		flag=true;
	}	
	else if(!Pass.equals(ConfirmPass)) {
		lblMsg.setText("Please make sure your passwords match");
		flag=true;
		
	}
	
	if(flag == false){
		
		Out= objUserBusiness.InsertInUserMaster(Name, Email, PhNum, Address, Uname, Pass);
				
	}
										
	if(Out.equals("1") ) {
		lblMsg.setText("Account has been created. Please login");
		ResetTxtFieldValues();
		
		
				
	}
	else if(Out.equals("-1")) {
		lblMsg.setText("Oops! Some error occurred");
				
	}
		
	else if(Out.equals("0"))  {						
		lblMsg.setText("A user with the same name or email ID already exists.");
	}						
	
		
	}
	public void Update() {
	}
	public void Delete() {
	}
	public void Read() {
		
	}
	
	
}
