package UIModule;

import java.awt.BorderLayout;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import BusinessLayer.ItemBusiness;

import java.sql.*;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import java.awt.Color;
import java.awt.Component;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.SystemColor;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import CommonInterface.CRUDInterface;
public class ItemMasterNew extends JFrame implements CRUDInterface {
	
	String connectionUrl = "jdbc:sqlserver://LAPTOP-9HEOT6R2\\SQLEXPRESS01;databaseName=StockManagement;user=Devansh;password=devansh21";
	Connection con;
	
	private JPanel contentPane;
	private JTextField txtItem;
	private JTextField txtSKU;
	private JTextField txtDesc;
	JLabel lblMsg;
	JComboBox comboBox;
	
	ItemBusiness objItem = new ItemBusiness();
	
	String [] Category = new String[] {};
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ItemMasterNew frame = new ItemMasterNew();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ItemMasterNew() {
		
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			con = DriverManager.getConnection(connectionUrl);
			
			
		}
		catch(Exception ex) {
			lblMsg.setText(ex.getMessage());
		}
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(-3, 60, 1545, 800);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(538, 161, 455, 411);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Item name");
		lblNewLabel_1.setBounds(48, 97, 108, 28);
		panel.add(lblNewLabel_1);
		lblNewLabel_1.setForeground(Color.BLACK);
		lblNewLabel_1.setFont(new Font("Calibri", Font.BOLD, 20));
		
		txtItem = new JTextField();
		txtItem.setBounds(180, 97, 246, 28);
		panel.add(txtItem);
		txtItem.setColumns(10);
		
		txtSKU = new JTextField();
		txtSKU.setBounds(178, 149, 248, 28);
		panel.add(txtSKU);
		txtSKU.setColumns(10);
		
		JLabel lblNewLabel_1_1 = new JLabel("SKU Code");
		lblNewLabel_1_1.setBounds(48, 151, 108, 25);
		panel.add(lblNewLabel_1_1);
		lblNewLabel_1_1.setForeground(Color.BLACK);
		lblNewLabel_1_1.setFont(new Font("Calibri", Font.BOLD, 20));
		
		JLabel lblNewLabel_1_2 = new JLabel("Description");
		lblNewLabel_1_2.setBounds(48, 198, 98, 38);
		panel.add(lblNewLabel_1_2);
		lblNewLabel_1_2.setForeground(Color.BLACK);
		lblNewLabel_1_2.setFont(new Font("Calibri", Font.BOLD, 20));
		
		txtDesc = new JTextField();
		txtDesc.setBounds(178, 203, 248, 28);
		panel.add(txtDesc);
		txtDesc.setColumns(10);
		
		JLabel lblNewLabel_1_3 = new JLabel("Category");
		lblNewLabel_1_3.setBounds(48, 256, 98, 33);
		panel.add(lblNewLabel_1_3);
		lblNewLabel_1_3.setForeground(Color.BLACK);
		lblNewLabel_1_3.setFont(new Font("Calibri", Font.BOLD, 20));
		
		comboBox = new JComboBox();
		comboBox.setBounds(178, 257, 248, 28);
		panel.add(comboBox);
		comboBox.setToolTipText("");
		
		JButton btnCreate = new JButton("Create Item");
		btnCreate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Insert();		
				
				
			}
		});
		btnCreate.setBounds(114, 329, 226, 38);
		panel.add(btnCreate);
		btnCreate.setFont(new Font("Calibri", Font.BOLD, 20));
		btnCreate.setBackground(SystemColor.controlShadow);
		
		JLabel lblNewLabel = new JLabel("Create item");
		lblNewLabel.setBounds(129, 34, 196, 38);
		panel.add(lblNewLabel);
		lblNewLabel.setForeground(Color.BLACK);
		lblNewLabel.setFont(new Font("Calibri", Font.BOLD, 30));
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setIcon(new ImageIcon("C:\\Users\\devan\\Downloads\\JBG3.jpg"));
		lblNewLabel_2.setBounds(0, 0, 455, 411);
		panel.add(lblNewLabel_2);
		
		lblMsg = new JLabel("");
		lblMsg.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblMsg.setBounds(458, 126, 1189, 38);
		contentPane.add(lblMsg);
		
		JLabel lblBG = new JLabel("");
		lblBG.setIcon(new ImageIcon("C:\\Users\\devan\\Downloads\\JBG3.jpg"));
		lblBG.setBounds(0, 0, 1545, 770);
		contentPane.add(lblBG);
		GetCategory();
	}
	
	
	
	public void Update() {
		
	}
	public void Delete() {
		
	}
	
	public void Read() {
		
	}
	
	public void Insert() {
		String out = "-1";
		
		String Item = txtItem.getText();
		String SKU = txtSKU.getText();
		String Desc = txtDesc.getText();
		String CatName = (String)comboBox.getSelectedItem();
		
		if(Item.isBlank() ) {
			JOptionPane.showMessageDialog(comboBox, "Enter the Item");
			
			
		}
		else if(SKU.isBlank()) {
			JOptionPane.showMessageDialog(comboBox, "Please enter the SKU Code");
			
			
		}
		else if(Desc.isBlank()) {
			JOptionPane.showMessageDialog(comboBox, "Please enter the description");
		
		}
		
		else {
			out = objItem.DBInsert(Item, SKU, Desc, CatName);
			
			if(out.equals("1")) {
				JOptionPane.showMessageDialog(null,"Item added successfully");
				
				txtItem.setText("");
				txtSKU.setText("");
				txtDesc.setText("");
			}
			else {
				JOptionPane.showMessageDialog(null,"An item with the same SKU code exists already" );
				
			}
		}
		
		
	}
	
	public void GetCategory() {
		
		Category = objItem.GetCategory_Insert();
		int ArrLen = Category.length;
		
		for(int i=0;i<ArrLen;i++) {
			comboBox.addItem(Category[i]);
		}
		
		
	}
	
	
	
}
