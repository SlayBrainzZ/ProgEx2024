package UIModule;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import ExceptionHandling.ExceptionMaster;

import java.sql.*;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import java.awt.Font;

public class ItemList extends JFrame {
	ExceptionMaster obj = new ExceptionMaster();
	
	String connectionUrl = "jdbc:sqlserver://LAPTOP-9HEOT6R2\\SQLEXPRESS01;databaseName=StockManagement;user=Devansh;password=devansh21";
	Connection con;
	DefaultTableModel objTableModel;
	private JPanel contentPane;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ItemList frame = new ItemList();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ItemList() {
		
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			con = DriverManager.getConnection(connectionUrl);
			
			
		}
		catch(Exception ex) {
			obj.InsertException(ex.getMessage(), "ItemList", "Constructor");
			
		}
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(-3, 80, 1545, 800);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		objTableModel = new DefaultTableModel();
		objTableModel.addColumn("ID");
		objTableModel.addColumn("Item");
		objTableModel.addColumn("SKU Code");
		objTableModel.addColumn("Description");
		objTableModel.addColumn("Category");
		getData();
		
		JLabel lblItems = new JLabel("Items List");
		lblItems.setFont(new Font("Gadugi", Font.BOLD, 22));
		lblItems.setBounds(712, 252, 112, 33);
		contentPane.add(lblItems);
		
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setFont(new Font("Tahoma", Font.BOLD, 16));
		scrollPane.setBounds(330, 306, 918, 194);
		contentPane.add(scrollPane);
		
		table = new JTable(objTableModel);
		table.setFont(new Font("Tahoma", Font.PLAIN, 14));
		scrollPane.setViewportView(table);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\devan\\Pictures\\BG 2.jpg"));
		lblNewLabel.setBounds(0, 0, 1545, 830);
		contentPane.add(lblNewLabel);
	}
	
	public void getData() {
		
		try {
			
			CallableStatement stmt = con.prepareCall("{call Proc_ItemMaster_Read}");
			
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()) {
				
				objTableModel.insertRow(0, new Object[] {rs.getInt("Item_ID"), rs.getString("Item_Name"), rs.getString("SKU_Code"), rs.getString("Description"), rs.getString("CategoryName")} );
				
			}
			
			
		}
		catch(Exception e) {
			obj.InsertException(e.getMessage(), "ItemList", "getData");
			JOptionPane.showMessageDialog(null, "Oops! An error occured. please try again in some time");
		}
		
	}
}
