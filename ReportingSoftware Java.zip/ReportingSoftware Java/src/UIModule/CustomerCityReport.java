package UIModule;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import BusinessLayer.CusCityReportBusiness;

import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.sql.*;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
public class CustomerCityReport extends JFrame {
	
	String connectionUrl = "jdbc:sqlserver://LAPTOP-9HEOT6R2\\SQLEXPRESS01;databaseName=StockManagement;user=Devansh;password=devansh21";
	Connection con;
	
	JLabel lblMsg;
	CusCityReportBusiness objReport = new CusCityReportBusiness(); 
	
	JComboBox comboBox;
	private JPanel contentPane;
	private JTable table;
	
	DefaultTableModel objTableModel = new DefaultTableModel(); 
	private JLabel lblNewLabel;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CustomerCityReport frame = new CustomerCityReport();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CustomerCityReport() {
		
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			con = DriverManager.getConnection(connectionUrl);
			
			
		}
		catch(Exception ex) {
			//obj.InsertException(ex.getMessage(), "CustomerCityReport", "Constructor");
			
		}
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(-5, 60, 1545, 800);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		comboBox = new JComboBox();
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String City = (String) comboBox.getSelectedItem();
				getCusNames();
				
			}
		});
		comboBox.setBounds(293, 301, 191, 29);
		contentPane.add(comboBox);
		
		objTableModel.addColumn("Customer Name");
		objTableModel.addColumn("City");
		
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(581, 298, 745, 215);
		contentPane.add(scrollPane);
		
		table = new JTable(objTableModel);
		scrollPane.setViewportView(table);
		
		lblMsg = new JLabel("");
		lblMsg.setFont(new Font("Tahoma", Font.PLAIN, 19));
		lblMsg.setBounds(450, 167, 761, 37);
		contentPane.add(lblMsg);
		
		lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(CustomerCityReport.class.getResource("/BackgroundImage/aqua BG.png")));
		lblNewLabel.setBounds(0, 0, 1545, 800);
		contentPane.add(lblNewLabel);
		
		populateComboBox();
	}
	
	public void populateComboBox() {
		
		String[] CusNames = new String[] {};
		CusNames = objReport.getCities();
		int Len = CusNames.length;
		
		for(int i=0;i<Len;i++) {
			
			comboBox.addItem(CusNames[i]);
			
		}
		
	}
	
	public void getCusNames() {
		
		String City = (String) comboBox.getSelectedItem();
		objTableModel.setRowCount(0);
		
		try {
			
			CallableStatement stmt = con.prepareCall("{call Proc_AccountMaster_CityReport(?)}");
			stmt.setString(1, City);
			
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()) {
				
				objTableModel.insertRow(0,new Object[] {rs.getString("Name"), City} );
				
			}
			
			
		}
		catch(Exception ex) {
			lblMsg.setText(ex.getMessage());
		}
		
		
	}
}
