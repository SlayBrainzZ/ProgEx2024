package UIModule;

import java.awt.BorderLayout;


import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;

import ExceptionHandling.ExceptionMaster;

import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Color;

public class MenuMaster extends JFrame implements ActionListener, MenuListener {
	
	JLabel lblUserText;
	JPanel panelUser;
	String connectionUrl = "jdbc:sqlserver://LAPTOP-9HEOT6R2\\SQLEXPRESS01;databaseName=StockManagement;user=Devansh;password=devansh21";
	
	Connection con;
	
	private JPanel contentPane;
	JMenuBar menuBar;
	JMenu mnMaster;
	JMenuItem mntmUserMaster;
	JMenuItem mntmUpdateUser;
	JMenuItem mntmDeleteUser ;
	JMenuItem mntmCusMaster;
	JMenuItem mntmUpdateCus;
	JMenuItem mntmDeleteCus;
	JMenuItem mtnmCtgMaster;
	JMenuItem mntmUpdateCtg;
	JMenuItem mntmDeleteCtg;
	JMenuItem mntmItemMaster;
	JMenuItem mntmUpdateItem;
	JMenuItem mntmDeleteItem;
	JMenu menuInput;
	JMenuItem mntmSales;
	JMenuItem mntmDeleteSales;
	JMenuItem mntmUpdateSales;
	JMenu mnReport;
	JMenu mnInvoice;
	ChartPanel panelChart;
	ChartPanel panelChart1;
	String Username;
	JMenuItem mntmCtgCityReport;
	JMenuItem mntmCitywiseSalesReport;
	JMenuItem mntmMonthlyRevReport;
	JMenuItem mntmCityCusReport;
	JMenuItem mntmUserList;
	JMenuItem mntmCusList;
	JMenuItem mntmCtgList;
	JMenuItem mntmItemList;
	JMenuItem mntmSalesList;
	
	int ArrLen;
	JFreeChart lineChart;
	
	Double[] Amount = new Double[] {};
	String[] Cities = new String[] {};
	
	Object[][] RevenueDetails = new Object[][] {};
	
	int RowCount = 0;
	
	JLabel lblMsg;

	ExceptionMaster obj = new ExceptionMaster();
	private JMenuItem mntmDatewiseRevenueReport;
	private JMenuItem mntmDatewiseSalesRpeort;
	private JLabel lblNewLabel;
	private JMenuItem mntmGenInvoice;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MenuMaster frame = new MenuMaster();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	
	
	public void MenuMaster1() {

	}
	
	public void MenuMaster() {
		
		
		//MenuMaster1();
	}
	
	
	public MenuMaster() {

		
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			con = DriverManager.getConnection(connectionUrl);
			
			
		}
		catch(Exception ex){
			obj.InsertException(ex.getMessage(), "LoginPageNew", "Constructor");
			
		}
		

		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\devan\\Pictures\\JViola (2).jpg"));
		setTitle("REPORTING SOFTWARE");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(-4, 0, 1545, 875);
		
		menuBar = new JMenuBar();
		menuBar.setBackground(new Color(135, 206, 250));
		setJMenuBar(menuBar);
		
		mnMaster = new JMenu("Master");
		mnMaster.setFont(new Font("Dubai", Font.BOLD, 15));
		menuBar.add(mnMaster);
		
		mntmUserMaster = new JMenuItem("User Master");
		mntmUserMaster.addActionListener(this);
		mntmUserMaster.setFont(new Font("Segoe UI", Font.BOLD, 13));
		mnMaster.add(mntmUserMaster);
		
		mntmUpdateUser = new JMenuItem("Update User");
		mntmUpdateUser.addActionListener(this);
		mntmUpdateUser.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		mnMaster.add(mntmUpdateUser);
		
		mntmDeleteUser = new JMenuItem("Delete User");
		mntmDeleteUser.addActionListener(this);
		mntmDeleteUser.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		mnMaster.add(mntmDeleteUser);
		
		mntmCusMaster = new JMenuItem("Customer Master");
		mntmCusMaster.addActionListener(this);
		
		mntmUserList = new JMenuItem("View User List");
		mntmUserList.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		mnMaster.add(mntmUserList);
		mntmUserList.addActionListener(this);
		
		mntmCusMaster.setFont(new Font("Segoe UI", Font.BOLD, 13));
		mnMaster.add(mntmCusMaster);
		
		
		mntmUpdateCus = new JMenuItem("Update Customer ");
		mntmUpdateCus.addActionListener(this);
		mntmUpdateCus.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		mnMaster.add(mntmUpdateCus);
		
		mntmDeleteCus = new JMenuItem("Delete Customer");
		mntmDeleteCus.addActionListener(this);
		mntmDeleteCus.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		mnMaster.add(mntmDeleteCus);
		
		mtnmCtgMaster = new JMenuItem("Category Master");
		mtnmCtgMaster.addActionListener(this);
		
		mntmCusList = new JMenuItem("View Customer List");
		mntmCusList.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		mnMaster.add(mntmCusList);
		mntmCusList.addActionListener(this);
		
		mtnmCtgMaster.setFont(new Font("Segoe UI", Font.BOLD, 13));
		mnMaster.add(mtnmCtgMaster);
		
		mntmUpdateCtg = new JMenuItem("Update Category");
		mntmUpdateCtg.addActionListener(this);
		mntmUpdateCtg.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		mnMaster.add(mntmUpdateCtg);
		
		mntmDeleteCtg = new JMenuItem("Delete Category");
		mntmDeleteCtg.addActionListener(this);
		mntmDeleteCtg.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		mnMaster.add(mntmDeleteCtg);
		
		mntmItemMaster = new JMenuItem("Item Master");
		mntmItemMaster.addActionListener(this);
		
		mntmCtgList = new JMenuItem("Category List");
		mntmCtgList.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		mnMaster.add(mntmCtgList);
		mntmCtgList.addActionListener(this);
		
		mntmItemMaster.setHorizontalAlignment(SwingConstants.LEFT);
		mntmItemMaster.setFont(new Font("Segoe UI", Font.BOLD, 13));
		mnMaster.add(mntmItemMaster);
		
		mntmUpdateItem = new JMenuItem("Update Item");
		mntmUpdateItem.addActionListener(this);
		mntmUpdateItem.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		mnMaster.add(mntmUpdateItem);
		
		mntmDeleteItem = new JMenuItem("Delete Item");
		mntmDeleteItem.addActionListener(this);
		mntmDeleteItem.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		mnMaster.add(mntmDeleteItem);
		
		mntmItemList = new JMenuItem("Item List");
		mntmItemList.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		mnMaster.add(mntmItemList);
		mntmItemList.addActionListener(this);
		
		menuInput = new JMenu("Input");
		menuInput.setFont(new Font("Dubai", Font.BOLD, 15));
		menuBar.add(menuInput);
		
		mntmSales = new JMenuItem("Sales");
		mntmSales.addActionListener(this);
		mntmSales.setHorizontalAlignment(SwingConstants.LEFT);
		mntmSales.setFont(new Font("Segoe UI", Font.BOLD, 13));
		menuInput.add(mntmSales);
		
		mntmDeleteSales = new JMenuItem("Delete Sales");
		mntmDeleteSales.addActionListener(this);
		mntmDeleteSales.setHorizontalAlignment(SwingConstants.LEFT);
		mntmDeleteSales.setMargin(new Insets(2, 0, 2, 2));
		mntmDeleteSales.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		menuInput.add(mntmDeleteSales);
		
		mntmUpdateSales = new JMenuItem("Update Sales");
		mntmUpdateSales.addActionListener(this);
		mntmUpdateSales.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		menuInput.add(mntmUpdateSales);
		
		mntmSalesList = new JMenuItem("View Sales");
		mntmSalesList.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		menuInput.add(mntmSalesList);
		
		mntmSalesList.addActionListener(this);
		
		
		mnReport = new JMenu("Report");
		mnReport.setFont(new Font("Dubai", Font.BOLD, 15));
		menuBar.add(mnReport);
		
		mntmCitywiseSalesReport = new JMenuItem("Citywise Sales Report");
		mnReport.add(mntmCitywiseSalesReport);
		mntmCitywiseSalesReport.addActionListener(this);
		
		mntmCityCusReport = new JMenuItem("Citywise Customer Report");
		mnReport.add(mntmCityCusReport);
		mntmCityCusReport.addActionListener(this);
		
		mntmCtgCityReport = new JMenuItem("Category City Report");
		mnReport.add(mntmCtgCityReport);
		mntmCtgCityReport.addActionListener(this);
		
		mntmDatewiseRevenueReport = new JMenuItem("Datewise Revenue Report");
		mnReport.add(mntmDatewiseRevenueReport);
		mntmDatewiseRevenueReport.addActionListener(this);
		
		mntmDatewiseSalesRpeort = new JMenuItem("Datewise Sales Report");
		mnReport.add(mntmDatewiseSalesRpeort);
		mntmDatewiseSalesRpeort.addActionListener(this);
		
		mntmMonthlyRevReport = new JMenuItem("Monthly Revenue Report");
		mnReport.add(mntmMonthlyRevReport);
		mntmMonthlyRevReport.addActionListener(this);
		
		mnInvoice = new JMenu("Invoice");
		mnInvoice.addMenuListener(this);
			
		mnInvoice.setFont(new Font("Dubai", Font.BOLD, 15));
		menuBar.add(mnInvoice);
		
		mntmGenInvoice = new JMenuItem("Generate Invoice");
		mnInvoice.add(mntmGenInvoice);
		mntmGenInvoice.addActionListener(this);
		
		panelUser = new JPanel();
		menuBar.add(panelUser);
		
		JLabel lblUsername = new JLabel("");
		lblUsername.setFont(new Font("Tahoma", Font.BOLD, 15));
		panelUser.add(lblUsername);
		
		lblUserText = new JLabel("");
		lblUserText.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblUserText.setText(Username);
		panelUser.add(lblUserText);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(MenuMaster.class.getResource("/BackgroundImage/aqua BG.png")));
		lblNewLabel.setBounds(10, 0, 1545, 875);

		getData();		
		pieChart();
		DisplayChart();
		
		lblMsg = new JLabel("");
		lblMsg.setFont(new Font("Tahoma", Font.BOLD, 17));
		lblMsg.setBounds(236, 10, 103, 41);
		contentPane.add(lblMsg);
		
		contentPane.add(lblNewLabel);
		
	}
	
	public void actionPerformed(ActionEvent e) {
		
		JMenuItem item = (JMenuItem)e.getSource();
		
		if(item == mntmItemList) {
			ItemList objItem = new ItemList();
			objItem.setVisible(true);
		}
		
		if(item == mntmUserList) {
			UserList objUser = new UserList();
			objUser.setVisible(true);
		}
		
		if(item == mntmSalesList) {
			
			SalesList objSales = new SalesList();
			objSales.setVisible(true);
		}
		
		
		
		if(item == mntmCtgList) {
			CategoryList objCtg = new CategoryList();
			objCtg.setVisible(true);
		}
		
		
		
		if(item == mntmCusList) {
			AccountMasterList objAcc = new AccountMasterList();
			objAcc.setVisible(true);
			
		}
		
		
		if(item == mntmGenInvoice) {
			CreateInvoice invoice = new CreateInvoice();
			invoice.setVisible(true);
		}
		
		if(item == mntmCitywiseSalesReport) {
			CitySalesReport citySales = new CitySalesReport();
			citySales.setVisible(true);
			
		}
		
		if(item == mntmCtgCityReport ) {
			CityWiseCategoryReport cityCtg = new CityWiseCategoryReport();
			cityCtg.setVisible(true);
		}
		
		if(item == mntmDatewiseRevenueReport ) {
			DateWiseRevenueReport datewiseRev = new DateWiseRevenueReport();
			datewiseRev.setVisible(true);
		}
		
		if(item == mntmDatewiseSalesRpeort ) {
			DateWiseSalesReport datewiseSales = new DateWiseSalesReport();
			datewiseSales.setVisible(true);
			
		}
		
		if(item == mntmMonthlyRevReport ) {
			MonthlyRevenueReport monthlyRev = new MonthlyRevenueReport();
			monthlyRev.setVisible(true);	
		}
		
		if(item == mntmCityCusReport ) {
			CustomerCityReport cusCityReport = new CustomerCityReport();
			cusCityReport.setVisible(true);	
		}
		
		if(item == mntmUserMaster ) {
			CreateNewUser userMaster = new CreateNewUser();
			userMaster.setVisible(true);
		}
		
		if(item == mntmUpdateUser) {
			UpdateUser updateUser = new UpdateUser();
			updateUser.setVisible(true);
		}
		
		if(item == mntmDeleteUser) {
			DeleteUser delUser = new DeleteUser();
			delUser.setVisible(true);
			
		}
		
		if(item == mntmCusMaster ) {
			AccountMaster AccMaster = new AccountMaster();
			AccMaster.setVisible(true);
		}
		
		if(item == mntmUpdateCus) {
			UpdateAccountMaster updateAcc = new UpdateAccountMaster();
			updateAcc.setVisible(true);
		}
		
		if(item == mntmDeleteCus) {
			DeleteAccountMaster delAcc = new DeleteAccountMaster();
			delAcc.setVisible(true);
		}
		
		if(item == mtnmCtgMaster ) {
			CategoryMaster Ctg = new CategoryMaster();
			Ctg.setVisible(true);
		}
		
		if(item == mntmUpdateCtg) {
			UpdateCategory updateCtg = new UpdateCategory();
			updateCtg.setVisible(true);
		}
		
		if(item == mntmDeleteCtg) {
			DeleteCategory delCtg = new DeleteCategory();
			delCtg.setVisible(true);
		}
		
		if(item == mntmItemMaster ) {
			ItemMasterNew ItemMaster = new ItemMasterNew();
			ItemMaster.setVisible(true);
		}
		
		if(item == mntmDeleteItem) {
			DeleteItem delItem = new DeleteItem();
			delItem.setVisible(true);
		}
		
		if(item == mntmUpdateItem) {
			UpdateItemMaster updateItem = new UpdateItemMaster();
			updateItem.setVisible(true);
		}
		
		if(item == mntmSales) {
			SalesMaster sales = new SalesMaster() ;
			sales.setVisible(true);
		}
		
		if(item == mntmDeleteSales) {
			DeleteSales deleteSales = new DeleteSales () ;
			deleteSales.setVisible(true);
		}
		
		if(item == mntmUpdateSales) {
			UpdateSalesMaster updateSales = new UpdateSalesMaster();
			updateSales.setVisible(true);
		}
		
		
	
	}
	
	public void DisplayChart() {
		
		try {
			
			DefaultCategoryDataset dataset = new DefaultCategoryDataset();
			
			if(ArrLen !=0) {
				
				for(int i=0;i<ArrLen;i++) {
					dataset.addValue(Amount[i], "Revenue", Cities[i]);
				}

				lineChart = ChartFactory.createBarChart("TITLE", "Cities", "Revenue", dataset, PlotOrientation.VERTICAL, true, true, false);

				panelChart = new ChartPanel(lineChart);
				panelChart.setBounds(100, 120, 639, 558);
				contentPane.add(panelChart);

			}
			
		}
		
		catch(Exception ex) {
			JOptionPane.showMessageDialog(null, " Oops! An error occured. Please try again later." );
		}
		
		

	}

	public void getData() {
		
		int Index=0;
		
		try {

			CallableStatement stmt = con.prepareCall("{call Proc_AccountMaster_DisplayInChart}", ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY );
			
			ResultSet rs = stmt.executeQuery();
			rs.last();
			
			ArrLen = rs.getRow();
			rs.beforeFirst();
			//JOptionPane.showMessageDialog(null, ArrLen+ "  A");
			
			Amount = new Double[ArrLen];
			Cities = new String[ArrLen];
			
			while(rs.next()) {

				Cities[Index] = rs.getString("City");
				Amount[Index] = rs.getDouble("Balance_Amount");
				Index++;
				
			}

		}
		catch(Exception ex) {
			
			obj.InsertException(ex.getMessage(), "MenuMaster", "getData");
			JOptionPane.showMessageDialog(null, ex );
		}
		
	}
	
	public void pieChart() {
		
		
		getRevDetails();
		DefaultPieDataset PieD = new DefaultPieDataset();
		
		if(RowCount!=0) {
			
			for(int i=0;i<RowCount;i++) {
				PieD.setValue(RevenueDetails[i][0].toString() , Double.parseDouble(RevenueDetails[i][1].toString()));
				
			}
			
			JFreeChart chart = ChartFactory.createPieChart("Monthly Revenue for current year", PieD, true, true, false);
			
			panelChart1= new ChartPanel(chart);
			
			panelChart1.setBounds(800, 120, 639, 558);
			contentPane.add(panelChart1);
			
		}

	}

	public void getRevDetails() {
		
		
		
		try {
			
			CallableStatement stmt = con.prepareCall("{call Proc_SalesMaster_MonthlyRevenue_Chart}", ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			ResultSet rs = stmt.executeQuery();
			
			rs.last();
			
			RowCount = rs.getRow();
			rs.beforeFirst();
			
			int r=0;
			RevenueDetails = new Object[RowCount][2];
			while(rs.next()) {
				
				RevenueDetails[r][0] = rs.getString("Month");
				RevenueDetails[r][1] = rs.getDouble("Amount");
				r++;
				
			}
			
			
		}
		catch(Exception ex) {
			obj.InsertException(ex.getMessage(), "MenuMaster", "getRevDetails");
			JOptionPane.showMessageDialog(null, "Oops! Something wrong occured. ");
			ex.printStackTrace();
		}
		
	}

	
	@Override
	
	public void menuSelected(MenuEvent e) {
		JMenu  menu = (JMenu) e.getSource();
		if(menu == mnInvoice) {
			
			//System.exit(0);
			
		}
		
	}

	@Override
	public void menuDeselected(MenuEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void menuCanceled(MenuEvent e) {
		// TODO Auto-generated method stub
		
	}
}
