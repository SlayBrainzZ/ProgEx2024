package UIModule;
import java.awt.BorderLayout;
import java.sql.*;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ResetPassword extends JFrame {
	
	
	String connectionUrl = "jdbc:sqlserver://LAPTOP-9HEOT6R2\\SQLEXPRESS01;databaseName=StockManagement;user=Devansh;password=devansh21";
	Connection con;
	private JPanel contentPane;
	private JTextField txtUname;
	private JTextField txtPass;
	private JTextField txtNewPass;
	private JTextField txtConfirm;
	JLabel lblErrorMsg;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ResetPassword frame = new ResetPassword();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ResetPassword() {
		
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			con = DriverManager.getConnection(connectionUrl);
			
			
		}
		catch(Exception ex) {
			//lblErrorMsg.setText(ex.getMessage()+ "IN CONSTRUCTOR");
			
		}
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(-5, 0, 1545, 870);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(413, 227, 328, 394);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Uname");
		lblNewLabel.setBounds(23, 47, 45, 13);
		panel.add(lblNewLabel);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setBounds(23, 110, 45, 13);
		panel.add(lblPassword);
		
		txtUname = new JTextField();
		txtUname.setBounds(104, 44, 188, 38);
		panel.add(txtUname);
		txtUname.setColumns(10);
		
		txtPass = new JTextField();
		txtPass.setColumns(10);
		txtPass.setBounds(104, 107, 188, 38);
		panel.add(txtPass);
		
		JButton btnNewButton = new JButton("New button");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Username = txtUname.getText();
				String OldPassword= txtPass.getText();
				String NewPassword = txtNewPass.getText();
				String ConfirmPass = txtConfirm.getText();
				
				if(NewPassword.equals(ConfirmPass)) {
					if(GetLogindetailsDB(Username, OldPassword, ConfirmPass) == 1) {
						JOptionPane.showMessageDialog(null, "Password has been updated");
						//obj.setVisible(true);
						
					}
					else {
						lblErrorMsg.setText("Wrong pass");
						
					}
					
				}
				else {
					
					lblErrorMsg.setText("Enter new password again and confirm password");
				}
				
			}
		});
		btnNewButton.setBounds(108, 279, 125, 49);
		panel.add(btnNewButton);
		
		txtNewPass = new JTextField();
		txtNewPass.setBounds(104, 179, 188, 38);
		panel.add(txtNewPass);
		txtNewPass.setColumns(10);
		
		JLabel lblNewpass = new JLabel("NewPass");
		lblNewpass.setBounds(23, 191, 45, 13);
		panel.add(lblNewpass);
		
		JLabel lblConfirmpass = new JLabel("ConfirmPass");
		lblConfirmpass.setBounds(23, 248, 45, 13);
		panel.add(lblConfirmpass);
		
		txtConfirm = new JTextField();
		txtConfirm.setColumns(10);
		txtConfirm.setBounds(108, 231, 188, 38);
		panel.add(txtConfirm);
		
		
	}
	
	public int GetLogindetailsDB(String Uname, String Pass, String NewPass) {
		
		int stmtEx= -1;
		try {
			CallableStatement stmt = con.prepareCall("{call Proc_UserMaster_ChangePassword(?,?,?)}");
			
			stmt.setString(1, Uname);
			stmt.setString(2, Pass);
			stmt.setString(3, NewPass);
			
			stmtEx = stmt.executeUpdate();
			lblErrorMsg.setText("2");
			
			
			lblErrorMsg.setText("stm : "+stmtEx);
			stmt.close();
					
		}
			
		
		catch(Exception ex) {
			lblErrorMsg.setText(ex.getMessage());
		}
		return stmtEx;
	}
}
