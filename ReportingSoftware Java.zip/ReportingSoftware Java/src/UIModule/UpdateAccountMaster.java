package UIModule;

import java.awt.BorderLayout;
import java.sql.*;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.border.MatteBorder;

import BusinessLayer.AccountBusiness;
import CommonInterface.CRUDInterface;


import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import java.util.*;
public class UpdateAccountMaster extends JFrame implements CRUDInterface {
	
	int CusID;
	AccountBusiness objAcc = new AccountBusiness();
	
	
	String connectionUrl = "jdbc:sqlserver://LAPTOP-9HEOT6R2\\SQLEXPRESS01;databaseName=StockManagement;user=Devansh;password=devansh21";
	Connection con;
	private JPanel contentPane;
	private JTextField txtEmail;
	private JTextField txtPhone;
	private JTextField txtCity;
	JLabel lblMsg ;
	JComboBox comboBox;
	
	private JTextField txtNewName;
	
	Object[][] CusID_Names = new Object[][] {};
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UpdateAccountMaster frame = new UpdateAccountMaster();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public UpdateAccountMaster() {
		
		
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			con = DriverManager.getConnection(connectionUrl);
			
			
		}
		catch(Exception ex) {
			lblMsg.setText(ex.getMessage());
		}
		
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(-5, 60, 1545, 800);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 255, 127)));
		panel.setBackground(new Color(0,0,0,0));
		panel.setBounds(521, 190, 474, 376);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Update Customer Details");
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Calibri", Font.BOLD, 25));
		lblNewLabel.setBounds(120, 20, 270, 36);
		panel.add(lblNewLabel);
		
		JLabel lblCustomerName = new JLabel("Customer Name");
		lblCustomerName.setForeground(new Color(255, 255, 255));
		lblCustomerName.setFont(new Font("Calibri", Font.BOLD, 20));
		lblCustomerName.setBounds(48, 80, 140, 36);
		panel.add(lblCustomerName);
		
		JLabel lblEmailid = new JLabel("Email - ID");
		lblEmailid.setForeground(new Color(255, 255, 255));
		lblEmailid.setFont(new Font("Calibri", Font.BOLD, 20));
		lblEmailid.setBounds(48, 172, 86, 36);
		panel.add(lblEmailid);
		
		txtEmail = new JTextField();
		txtEmail.setColumns(10);
		txtEmail.setBounds(227, 173, 185, 28);
		panel.add(txtEmail);
		
		JLabel lblPhoneNumber = new JLabel("Phone Number");
		lblPhoneNumber.setForeground(new Color(255, 255, 255));
		lblPhoneNumber.setFont(new Font("Calibri", Font.BOLD, 20));
		lblPhoneNumber.setBounds(48, 218, 140, 36);
		panel.add(lblPhoneNumber);
		
		txtPhone = new JTextField();
		txtPhone.setColumns(10);
		txtPhone.setBounds(227, 219, 185, 28);
		panel.add(txtPhone);
		
		JLabel lblCity = new JLabel("City");
		lblCity.setForeground(new Color(255, 255, 255));
		lblCity.setFont(new Font("Calibri", Font.BOLD, 20));
		lblCity.setBounds(48, 264, 46, 36);
		panel.add(lblCity);
		
		txtCity = new JTextField();
		txtCity.setColumns(10);
		txtCity.setBounds(227, 265, 185, 28);
		panel.add(txtCity);
		
		JButton btnSubmit = new JButton("Submit");
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//comboBox.removeAllItems();
				Update();

			}
		});
		btnSubmit.setVerticalAlignment(SwingConstants.TOP);
		btnSubmit.setFont(new Font("Calibri", Font.BOLD, 20));
		btnSubmit.setBounds(144, 320, 185, 28);
		panel.add(btnSubmit);
		
		comboBox = new JComboBox();
		
		comboBox.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				JComboBox combo= (JComboBox) e.getSource();
				ComboBox cmbBox = (ComboBox) combo.getSelectedItem();
				
				CusID = cmbBox.getCusID();
				
				String CusName = cmbBox.getCusName();

				//getUserDetails();	
				
				getCusDetails(CusID);
				
				txtNewName.setText(CusName);
				
			}
		});
		comboBox.setBounds(227, 87, 185, 28);
		panel.add(comboBox);
		
		txtNewName = new JTextField();
		txtNewName.setColumns(10);
		txtNewName.setBounds(227, 130, 185, 28);
		panel.add(txtNewName);
		
		JLabel lblNewName = new JLabel("New Name");
		lblNewName.setForeground(Color.WHITE);
		lblNewName.setFont(new Font("Calibri", Font.BOLD, 20));
		lblNewName.setBounds(48, 126, 140, 36);
		panel.add(lblNewName);
		
		lblMsg = new JLabel("");
		lblMsg.setBackground(new Color(255, 255, 255));
		lblMsg.setForeground(new Color(0, 191, 255));
		lblMsg.setFont(new Font("Calibri", Font.BOLD, 20));
		lblMsg.setBounds(10, 66, 504, 594);
		contentPane.add(lblMsg);
		
		JLabel lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\devan\\Downloads\\Grd BG.jpg"));
		lblNewLabel_1.setBounds(0, 0, 1831, 1038);
		contentPane.add(lblNewLabel_1);
		
		JLabel label = new JLabel("New label");
		label.setBounds(65, 241, 45, 13);
		contentPane.add(label);
		populateComboBox();
	}
	
	public void resetComboBox() {
		
	}
	
	public void Insert() {
	}
	public void Delete() {
	}
	public void Read() {
	}
	
	public void Update() {
		
		try {
			
			String Name = comboBox.getSelectedItem().toString();
			
			String NewName = txtNewName.getText();
			String Email = txtEmail.getText();
			String Phone = txtPhone.getText();
			String City = txtCity.getText();
			
			if(NewName.isBlank()) {
				JOptionPane.showMessageDialog(null, "Name cannot be empty");
			}
			
			else if(Email.isBlank()) {
				JOptionPane.showMessageDialog(null, "Email cannot be empty");
			}
			else if(Phone.isBlank()) {
				JOptionPane.showMessageDialog(null, "Phone number cannot be empty");
			}
			else if(City.isBlank()) {
				JOptionPane.showMessageDialog(null, "City cannot be empty");
			}
			
			else {
				objAcc.UpdateCusDetailsDB(CusID,Name, NewName, Email,Phone,City);
				populateComboBox();
				JOptionPane.showMessageDialog(null, "Details have been successfully updated");
				
			}
		}
		
		catch(Exception e) {
			JOptionPane.showMessageDialog(null, e);
			e.printStackTrace();
		}
		
		
		
		
	}
	
	public void getUserDetails() {
		String Name = (String) comboBox.getSelectedItem();
		
		Dictionary CusDetails = objAcc.GetCustomerDetails(Name);
		//CusID = (Integer) CusDetails.get("AccID");
		txtEmail.setText( (String)CusDetails.get("EmailID"));
		txtPhone.setText((String) CusDetails.get("Phone") );
		txtCity.setText((String) CusDetails.get("City"));
	
		
	}
	
	public void getCusDetails(int CusID) {
		
		String Name =  comboBox.getSelectedItem().toString();
		
		String[][] CusDetails = new String[][] {};
		
		CusDetails = objAcc.GetCustomerDetailsUsingArr(CusID);
		
		
		
		for(int i=0;i<1;i++) {
			for(int j=0;j<3;j++) {
				
				if(j==0) {
					txtEmail.setText(CusDetails[0][j]);  
				}
				else if(j==1) {
					txtPhone.setText(CusDetails[0][j]);
				}
				else if(j==2) {
					txtCity.setText(CusDetails[0][j]);
					 
				}
				
				
			}
		}
			
	}
	
	public void populateComboBox() {
		//comboBox = new JComboBox();
		//comboBox.removeAllItems();
		
		int ArrLen = 0;
		
		Object[][] CusDetails = new Object[][] {};
		
		//CusDetails =  objAcc.getCusNames_Update();
		
		CusID_Names = objAcc.getCusNames_Update();
		
		ArrLen = CusID_Names.length;
	
		for(int i =0;i<ArrLen;i++) {
			
			comboBox.addItem(new ComboBox( Integer.parseInt(CusID_Names[i][1].toString()), CusID_Names[i][0].toString()));
		}
	}
}

class ComboBox {
	
	int CusID;
	String CusName;
	
	public ComboBox(int cusID, String Name) {
		CusID = cusID;
		CusName= Name;
		
	}
	
	public void setCusID(int CusID) {
		
		this.CusID = CusID;
		
	}
	
	
	
	public int getCusID() {
		
		return CusID;
	}
	
	public void setCusName(String Name) {
		CusName = Name;
	}
	
	public String getCusName() {
		return CusName;
	}
	
	@Override
	public String toString() {
		return CusName;
	}
	
}


