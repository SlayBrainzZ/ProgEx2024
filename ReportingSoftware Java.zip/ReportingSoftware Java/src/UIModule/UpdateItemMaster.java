package UIModule;

import java.awt.BorderLayout;
import java.sql.*;
import java.util.Dictionary;
import java.util.Hashtable;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.border.LineBorder;

import BusinessLayer.ItemBusiness;
import CommonInterface.CRUDInterface;

import java.awt.Color;
import javax.swing.JComboBox;
import javax.swing.ImageIcon;

public class UpdateItemMaster extends JFrame implements CRUDInterface {
	String connectionUrl = "jdbc:sqlserver://LAPTOP-9HEOT6R2\\SQLEXPRESS01;databaseName=StockManagement;user=Devansh;password=devansh21";
	Connection con;
	JTextArea textAreaDesc;
	JLabel lblMsg;
	private JPanel contentPane;
	private JTextField txtSKU;
	private JTextField txtNewName;
	private JTextField txtDesc;
	
	String[] Items = new String[] {};
	
	JComboBox comboBox;
	String ID; 
	String Name;
	String SKU; 
	String Desc; 
	String out;
	
	ItemBusiness objItem  = new ItemBusiness(); 
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UpdateItemMaster frame = new UpdateItemMaster();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public UpdateItemMaster() {
		
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			con = DriverManager.getConnection(connectionUrl);
			
			
		}
		catch(Exception ex) {
			//lblMsg.setText(ex.getMessage());
		}
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(-5, 0, 1545, 870);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel.setBounds(569, 215, 480, 379);
		//panel.setOpaque(false);
		
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Item Name");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel.setBounds(77, 97, 117, 33);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("SKU Code");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(77, 191, 93, 26);
		panel.add(lblNewLabel_1);
		
		txtSKU = new JTextField();
		txtSKU.setBounds(244, 192, 190, 26);
		panel.add(txtSKU);
		txtSKU.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("New Item Name");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_2.setBounds(77, 151, 157, 26);
		panel.add(lblNewLabel_2);
		
		txtNewName = new JTextField();
		txtNewName.setBounds(244, 151, 190, 26);
		panel.add(txtNewName);
		txtNewName.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Description");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_3.setBounds(77, 233, 106, 26);
		panel.add(lblNewLabel_3);
		//String a = txtAreaDesc.
		
		JButton btnNewButton = new JButton("Update");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Update();

			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton.setBounds(168, 321, 144, 33);
		panel.add(btnNewButton);
		
		txtDesc = new JTextField();
		txtDesc.setBounds(244, 233, 190, 26);
		panel.add(txtDesc);
		txtDesc.setColumns(10);
		
		comboBox = new JComboBox();
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				getItemDetails();
				
				
			}
		});
		comboBox.setBounds(244, 103, 187, 28);
		panel.add(comboBox);
		
		JLabel lblUpdateItemName = new JLabel("Update Item Name");
		lblUpdateItemName.setFont(new Font("Dubai", Font.BOLD, 24));
		lblUpdateItemName.setBounds(134, 21, 211, 33);
		panel.add(lblUpdateItemName);
		
		JLabel lblNewLabel_5 = new JLabel("");
		lblNewLabel_5.setBounds(0, 0, 480, 379);
		panel.add(lblNewLabel_5);
		
		lblMsg = new JLabel("");
		lblMsg.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblMsg.setBounds(471, 124, 691, 44);
		contentPane.add(lblMsg);
		
		JLabel lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.setIcon(new ImageIcon("C:\\Users\\devan\\Downloads\\JBG3.jpg"));
		lblNewLabel_4.setBounds(0, 0, 1545, 875);
		contentPane.add(lblNewLabel_4);
		populateCombobox();
	}
	
	public void Insert() {
	}
	public void Delete() {
	}
	public void Read() {
	}
	
	public void populateCombobox() {
		Items = objItem.populateCombobox_Update();
		int ArrLen = Items.length;
		
		comboBox.removeAllItems();
		
		for(int i=0;i<ArrLen;i++) {
			comboBox.addItem(Items[i]);
		}
		
		
	}
	
		
	public void getItemDetails() {
		
		String[][] ItemDetails = new String[][] {};
		String Item = (String) comboBox.getSelectedItem();
		ItemDetails = objItem.getItemDetails(Item);
		int Len = ItemDetails.length;
		
		for(int i=0;i<Len;i++) {
			for(int j=0;j<2;j++) {
				
				if(j==0) {
					txtSKU.setText(ItemDetails[i][j]);
					
				}
				else {
					txtDesc.setText(ItemDetails[i][j]);
					
				}
				
			}
		}
		
		
	}
	
	
	public void Update() {
		
		String Oldname = (String) comboBox.getSelectedItem() ;
		Name = txtNewName.getText();
		SKU = txtSKU.getText();
		Desc = txtDesc.getText();
		
		if(Name.isBlank()) {
			lblMsg.setText("Enter the item name");
			
		}
		
		else if(SKU.isBlank()) {
			lblMsg.setText("Enter the SKU Code");
			
		}
		
		else {
			objItem.UpdateItem(Oldname,Name, SKU, Desc);
			lblMsg.setText("Item details were updated successfully");
			
			txtNewName.setText("");
			txtSKU.setText("");
			txtDesc.setText("");
		}
	}

}


