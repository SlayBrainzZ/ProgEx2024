package UIModule;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import BusinessLayer.ItemReportBusiness;

import javax.swing.JTable;
import javax.swing.JButton;
import javax.swing.JComboBox;
import java.util.*;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.ImageIcon;
public class ItemReport extends JFrame {
	JComboBox comboBox;
	DefaultTableModel objTableModel;
	JLabel lblMsg;
	private JPanel contentPane;
	private JTable table;
	
	ItemReportBusiness objItem = new ItemReportBusiness();
	private JScrollPane scrollPane;
	private JLabel lblNewLabel;
	
	String connectionUrl = "jdbc:sqlserver://LAPTOP-9HEOT6R2\\SQLEXPRESS01;databaseName=StockManagement;user=Devansh;password=devansh21";
	Connection con;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ItemReport frame = new ItemReport();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ItemReport() {
		
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			con = DriverManager.getConnection(connectionUrl);
			
			
		}
		catch(Exception ex) {
			//obj.InsertException(ex.getMessage(), "ItemReportBusiness", "Constructor");
			
		}
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(-5, 60, 1545, 800);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		lblMsg = new JLabel("");
		lblMsg.setFont(new Font("Tahoma", Font.PLAIN, 19));
		lblMsg.setBounds(288, 194, 338, 37);
		contentPane.add(lblMsg);
		
		objTableModel = new DefaultTableModel();
		table = new JTable(objTableModel);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(574, 303, 775, 284);
		contentPane.add(scrollPane);
		scrollPane.setViewportView(table);
		
		objTableModel.addColumn("Category");
		objTableModel.addColumn("Item");
		objTableModel.addColumn("Description");
		objTableModel.addColumn("SKU Code");
		
		comboBox = new JComboBox();
		comboBox.setBounds(288, 303, 170, 29);
		contentPane.add(comboBox);
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Ctg = (String) comboBox.getSelectedItem();
				
				getItemDetailsDB(Ctg);
				
				//getItemDetails();
			}
		});
		
		getCategories();
		
		
	
		lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\devan\\Pictures\\BG 2.jpg"));
		lblNewLabel.setBounds(0, 0, 1545, 800);
		contentPane.add(lblNewLabel);

	}
	
	public void getCategories() {
		
		String[] Categories = new String[] {};
		int Len=0;
		
		Categories = objItem.getCategories();
		Len= Categories.length;
		
		
		for(int i =0;i<Len;i++) {
			comboBox.addItem(Categories[i]);
		}
		
	}
	
	public void getItemDetails() {
		
		
		//objTableModel.insertRow(0, new Object[] { });
		String Ctg = (String) comboBox.getSelectedItem();
		
		Dictionary ItemDetails = new Hashtable();
		
		ItemDetails = objItem.getItemDetails(Ctg);
		
		
		lblMsg.setText(""+ItemDetails.size());
		
		
		objTableModel.insertRow(0, new Object[] { Ctg ,ItemDetails.get("Item"), ItemDetails.get("Desc") , ItemDetails.get("SKU")});
		
	}
	
	public void getItemDetailsDB(String Ctg) {
		
		//String Ctg = (String) comboBox.getSelectedItem();
		
		try {
			
			CallableStatement stmt = con.prepareCall("{call Proc_ItemMaster_ItemReport(?)}");
			stmt.setString(1, Ctg);
			
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()) {
				
				objTableModel.insertRow(0, new Object[] { Ctg, rs.getString("Item_Name"), rs.getString("Description"), rs.getString("SKU_Code")} );
		
			}
			
			
		}
		catch(Exception ex) {
			lblMsg.setText(ex.getMessage());
		}

	}
	

	
}
