package UIModule;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import ExceptionHandling.ExceptionMaster;

import java.sql.*;
import javax.swing.JTable;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
public class DateWiseSalesReport extends JFrame {

	ExceptionMaster obj = new ExceptionMaster();
	DefaultTableModel objTableModel = new DefaultTableModel();
	
	String connectionUrl = "jdbc:sqlserver://LAPTOP-9HEOT6R2\\SQLEXPRESS01;databaseName=StockManagement;user=Devansh;password=devansh21";
	Connection con;
	
	int RowCount = 0;
	
	private JPanel contentPane;
	private JTable table;
	private JTextField txtStartDate;
	private JTextField txtEndDate;
	private JScrollPane scrollPane;
	private JLabel lblNewLabel;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DateWiseSalesReport frame = new DateWiseSalesReport();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DateWiseSalesReport() {
		
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			con = DriverManager.getConnection(connectionUrl);
			
			
		}
		catch(Exception ex) {
			obj.InsertException(ex.getMessage(), "SalesReportBusiness", "Constructor");
			
		}
		
	
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(-5, 60, 1545, 800);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		objTableModel.addColumn("Date");
		
		objTableModel.addColumn("Sales");
		
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(562, 313, 543, 214);
		contentPane.add(scrollPane);
		
		table = new JTable(objTableModel);
		scrollPane.setViewportView(table);
		
		txtStartDate = new JTextField();
		txtStartDate.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				if(txtStartDate.getText().equals("YYYY-MM-DD")) {
					txtStartDate.setText("");
				}
			}
		});
		txtStartDate.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtStartDate.setText("YYYY-MM-DD");
		txtStartDate.setBounds(68, 311, 140, 30);
		contentPane.add(txtStartDate);
		txtStartDate.setColumns(10);
		
		txtEndDate = new JTextField();
		txtEndDate.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				if(txtEndDate.getText().equals("YYYY-MM-DD")) {
					txtEndDate.setText("");
					
				}
				
			}
		});
		
		txtEndDate.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtEndDate.setText("YYYY-MM-DD");
		txtEndDate.setColumns(10);
		txtEndDate.setBounds(239, 311, 140, 30);
		contentPane.add(txtEndDate);
		
		JButton btnNewButton = new JButton("Fetch Sales");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				getSales();
			}
		});
		btnNewButton.setVerticalAlignment(SwingConstants.BOTTOM);
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton.setBounds(164, 390, 140, 30);
		contentPane.add(btnNewButton);
		
		lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(DateWiseSalesReport.class.getResource("/BackgroundImage/aqua BG.png")));
		lblNewLabel.setBounds(0, 0, 1545, 800);
		contentPane.add(lblNewLabel);
	}
	
	public void getSales() {
		String StartDate = txtStartDate.getText(); 
		String EndDate = txtEndDate.getText();
		objTableModel.setRowCount(0);
		try {
	
			CallableStatement stmt = con.prepareCall("{call Proc_SalesMasterReport_DateWiseSales(?,?)}");
			
			stmt.setString(1, StartDate);
			stmt.setString(2, EndDate);
			
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()) {
				
				objTableModel.insertRow(0, new Object[] {rs.getString("TransactionDate"),rs.getDouble("Amount")} );
	
			}
			
			
			
		}
		catch(Exception ex) {
			obj.InsertException(ex.getMessage(), "SalesReportBusiness", "getSales");
		}

	}

	
}
