package UIModule;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import BusinessLayer.CitySalesReportBusiness;

import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.ImageIcon;

public class CitySalesReport extends JFrame {
	DefaultTableModel objTableModel= new DefaultTableModel();
	JComboBox comboBox;
	JLabel lblMsg;
	
	private JPanel contentPane;
	private JTable table;
	
	CitySalesReportBusiness objReport = new CitySalesReportBusiness();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CitySalesReport frame = new CitySalesReport();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CitySalesReport() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(-5, 60, 1545, 800);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		comboBox = new JComboBox();
		comboBox.setBounds(179, 282, 176, 27);
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				objTableModel.setRowCount(0);
				
				String City = (String) comboBox.getSelectedItem();
				
				int totalCus = getCustomers(City);
				double Rev = getRevenue(City);
				
				objTableModel.insertRow(0, new Object[] { City, totalCus, Rev } );
				
			}
		});
		contentPane.setLayout(null);
		contentPane.add(comboBox);
		
		objTableModel.addColumn("City");
		objTableModel.addColumn("No. of Customers");
		objTableModel.addColumn("Revenue");
		
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(423, 288, 665, 225);
		contentPane.add(scrollPane);
		
		table = new JTable(objTableModel);
		scrollPane.setViewportView(table);
		
		lblMsg = new JLabel("");
		lblMsg.setBounds(179, 230, 215, 42);
		lblMsg.setFont(new Font("Tahoma", Font.PLAIN, 20));
		contentPane.add(lblMsg);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(3, 2, 1545, 800);
		lblNewLabel.setIcon(new ImageIcon(CitySalesReport.class.getResource("/BackgroundImage/aqua BG.png")));
		contentPane.add(lblNewLabel);
		
		populateComboBox();
		
		
	}
	
	public void populateComboBox() {
		int Len=0;
		String[] Cities = new String[] {};
		
		Cities = objReport.getCities();
		Len = Cities.length;
		
		for(int i=0;i<Len;i++) {
			comboBox.addItem(Cities[i]);
		}
		
	}
	
	public double getRevenue(String City) {
		
		double Revenue = objReport.getRevenue(City);
		//lblMsg.setText(""+ Revenue);
		return Revenue;
		
		
	}
	
	public int getCustomers(String City) {
		
		int TotalCus= 0;
		
		TotalCus = objReport.getTotalCus(City);
		
		
		return TotalCus;
		
	}
}
