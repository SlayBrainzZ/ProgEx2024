package UIModule;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.Color;
import javax.swing.border.LineBorder;

import BusinessLayer.CategoryBusiness;

import CommonInterface.CRUDInterface;
import ExceptionHandling.ExceptionMaster;

import java.sql.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class CategoryMaster extends JFrame implements CRUDInterface {
	String ConnectionURL = "jdbc:sqlserver://LAPTOP-9HEOT6R2\\\\SQLEXPRESS01;databaseName=StockManagement;user=Devansh;password=devansh21";
	Connection con;
	
	ExceptionMaster objEx = new ExceptionMaster();
	CategoryBusiness objCat = new CategoryBusiness();
	
	private JPanel contentPane;
	private JTextField txtCtg;
	JLabel lblMsg;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CategoryMaster frame = new CategoryMaster();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CategoryMaster() {
		
		
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(-5, 60, 1545, 800);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		lblMsg = new JLabel("");
		lblMsg.setForeground(Color.RED);
		lblMsg.setFont(new Font("Dubai", Font.BOLD, 20));
		lblMsg.setBounds(538, 206, 512, 36);
		contentPane.add(lblMsg);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 206, 209)));
		
		panel.setBounds(538, 266, 391, 237);
		contentPane.add(panel);
		panel.setLayout(null);
		
		txtCtg = new JTextField();
		txtCtg.setBounds(146, 92, 198, 28);
		panel.add(txtCtg);
		txtCtg.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Create category");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("Calibri", Font.BOLD, 26));
		lblNewLabel.setBounds(92, 32, 198, 38);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Category");
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setFont(new Font("Calibri", Font.BOLD, 20));
		lblNewLabel_1.setBounds(35, 90, 94, 32);
		panel.add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("Submit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Insert();
			}
		});
		btnNewButton.setVerticalAlignment(SwingConstants.BOTTOM);
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setBackground(new Color(0, 51, 255));
		btnNewButton.setFont(new Font("Calibri", Font.BOLD, 20));
		btnNewButton.setBounds(92, 151, 190, 36);
		panel.add(btnNewButton);
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(new ImageIcon(CategoryMaster.class.getResource("/BackgroundImage/BG 2.jpg")));
		lblNewLabel_3.setBounds(0, 0, 391, 237);
		panel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setIcon(new ImageIcon(CategoryMaster.class.getResource("/BackgroundImage/aqua BG.png")));
		lblNewLabel_2.setBounds(0, 0, 1845, 800);
		contentPane.add(lblNewLabel_2);
	}
	
	public void Update() {
		
	}
	public void Delete() {
		
	}
	public void Read() {
		
	}
	
	public void Insert() {
		
		String Ctg = txtCtg.getText();
		
		if(Ctg.isBlank()) {
			JOptionPane.showMessageDialog(null, "Category cannot be blank");
			
		}
		else {
			objCat.InsertInCatMaster(Ctg);
			JOptionPane.showMessageDialog(null, "Category has been entered successfully");
			txtCtg.setText("");
		}
	
	}
	
}
