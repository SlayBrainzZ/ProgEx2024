package UIModule;
import java.awt.BorderLayout;
import java.sql.*;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import BusinessLayer.AccountBusiness;
import CommonInterface.CRUDInterface;
import ExceptionHandling.ExceptionMaster;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class AccountMaster extends JFrame implements CRUDInterface {
	
	
	JLabel lblMsg ;
	String out= "";
	
	ExceptionMaster obj = new ExceptionMaster();
	AccountBusiness objAcc = new AccountBusiness();
	
	private JPanel contentPane;
	private JTextField txtCusName;
	private JTextField txtEmail;
	private JTextField txtPhone;
	private JTextField txtAdd1;
	private JTextField txtAdd2;
	private JTextField txtAdd3;
	private JTextField txtCity;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AccountMaster frame = new AccountMaster();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AccountMaster() {
								
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(-7, 60, 1545, 800);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(326, 201, 846, 352);
		contentPane.add(panel);
		panel.setLayout(null);
		
		txtCity = new JTextField();
		txtCity.setColumns(10);
		txtCity.setBounds(219, 244, 164, 29);
		panel.add(txtCity);
		
		JLabel lblCity_3 = new JLabel("City");
		lblCity_3.setFont(new Font("Arial", Font.BOLD, 16));
		lblCity_3.setBounds(51, 242, 62, 32);
		panel.add(lblCity_3);
		
		JLabel lblCity_1 = new JLabel("Address Line 2");
		lblCity_1.setFont(new Font("Arial", Font.BOLD, 16));
		lblCity_1.setBounds(449, 161, 126, 32);
		panel.add(lblCity_1);
		
		txtAdd3 = new JTextField();
		txtAdd3.setColumns(10);
		txtAdd3.setBounds(574, 206, 164, 29);
		panel.add(txtAdd3);
		
		txtAdd2 = new JTextField();
		txtAdd2.setColumns(10);
		txtAdd2.setBounds(574, 164, 164, 29);
		panel.add(txtAdd2);
		
		JLabel lblCity_2 = new JLabel("Address Line 3");
		lblCity_2.setFont(new Font("Arial", Font.BOLD, 16));
		lblCity_2.setBounds(449, 203, 126, 32);
		panel.add(lblCity_2);
		
		JLabel lblNewLabel = new JLabel("Customer Name");
		lblNewLabel.setFont(new Font("Arial", Font.BOLD, 16));
		lblNewLabel.setBounds(51, 112, 133, 32);
		panel.add(lblNewLabel);
		
		JLabel lblEmail = new JLabel("Email ID");
		lblEmail.setFont(new Font("Arial", Font.BOLD, 16));
		lblEmail.setBounds(51, 156, 133, 32);
		panel.add(lblEmail);
		
		JLabel lblPhoneNumber = new JLabel("Phone Number");
		lblPhoneNumber.setFont(new Font("Arial", Font.BOLD, 16));
		lblPhoneNumber.setBounds(51, 198, 133, 32);
		panel.add(lblPhoneNumber);
		
		JLabel lblCity = new JLabel("Address Line 1");
		lblCity.setFont(new Font("Arial", Font.BOLD, 16));
		lblCity.setBounds(450, 114, 126, 32);
		panel.add(lblCity);
		
		JButton btnSubmit = new JButton("Submit");
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Insert();
			}
		});
		btnSubmit.setVerticalAlignment(SwingConstants.TOP);
		btnSubmit.setFont(new Font("Calibri", Font.BOLD, 20));
		btnSubmit.setBounds(347, 292, 152, 29);
		panel.add(btnSubmit);
		
		txtCusName = new JTextField();
		txtCusName.setBounds(219, 114, 164, 29);
		panel.add(txtCusName);
		txtCusName.setColumns(10);
		
		txtEmail = new JTextField();
		txtEmail.setColumns(10);
		txtEmail.setBounds(219, 160, 164, 29);
		panel.add(txtEmail);
		
		txtPhone = new JTextField();
		txtPhone.setColumns(10);
		txtPhone.setBounds(219, 202, 164, 29);
		panel.add(txtPhone);
		
		txtAdd1 = new JTextField();
		txtAdd1.setColumns(10);
		txtAdd1.setBounds(575, 117, 164, 29);
		panel.add(txtAdd1);
		
		JLabel lblNewLabel_1 = new JLabel("Customer Details");
		lblNewLabel_1.setFont(new Font("Calibri", Font.BOLD, 21));
		lblNewLabel_1.setBounds(347, 21, 152, 29);
		panel.add(lblNewLabel_1);
		
		JLabel lblPanelBG = new JLabel("New label");
		lblPanelBG.setIcon(new ImageIcon(AccountMaster.class.getResource("/BackgroundImage/BG 2.jpg")));
		lblPanelBG.setBounds(0, 0, 864, 352);
		panel.add(lblPanelBG);
		
		lblMsg = new JLabel("");
		lblMsg.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblMsg.setBounds(471, 76, 725, 43);
		contentPane.add(lblMsg);
		
		JLabel lblBG = new JLabel("");
		lblBG.setIcon(new ImageIcon(AccountMaster.class.getResource("/BackgroundImage/aqua BG.png")));
		lblBG.setBounds(0, 0, 1805, 871);
		contentPane.add(lblBG);
	}
	
	public void Update() {
	}
	public void Delete() {
	}
	public void Read() {
	}
	
	public void Insert() {
		
		
		String Name = txtCusName.getText();
		String Email = txtEmail.getText();
		String Phone = txtPhone.getText();
		String Add1 = txtAdd1.getText();
		String Add2 = txtAdd2.getText();
		String Add3 = txtAdd3.getText();
		String City = txtCity.getText();
		
		boolean Flag = true;
						

		if(Name.isBlank()) {
			JOptionPane.showMessageDialog(null, "Name cannot be blank");
			Flag = false;
		}
		
		else if(Email.isBlank()) {
			JOptionPane.showMessageDialog(null, "Email cannot be blank");
			
			Flag = false;
		}
		
		else if(Phone.isBlank()) {
			JOptionPane.showMessageDialog(null, "Phone Number cannot be blank");
				
			Flag = false;
		}
		
		else if(City.isBlank()) {
			JOptionPane.showMessageDialog(null, "City cannot be blank");
			
			Flag = false;
		}
		
		
		else if(Add1.isBlank()) {
			JOptionPane.showMessageDialog(null, "Address cannot be blank");
			Flag = false;
		}
		
		else if(Add2.isBlank()) {
			JOptionPane.showMessageDialog(null, "Address cannot be blank");
			Flag = false;
		}
		else if(Add3.isBlank()) {
			JOptionPane.showMessageDialog(null, "Address cannot cannot be blank");
			Flag = false;
		}
		
		
		
		if(Flag == true) {
			out= objAcc.InsertCusDetails(Name, Email, Phone, Add1, Add2, Add3, City);

		}
		
		if(out.equals("1")) {
			JOptionPane.showMessageDialog(null, "Details have been saved");
			
			txtCusName.setText("");
			txtEmail.setText("");
			txtPhone.setText("");
			txtAdd1.setText("");
			txtCity.setText("");
			txtAdd2.setText("");
			txtAdd3.setText("");
			
		}
		
		else if(out.equals("-2")) {
			JOptionPane.showMessageDialog(null, "A customer with the same phone number and email ID already exists");
			
		}
		else if(out.equals("-3")) {
			JOptionPane.showMessageDialog(null, "A customer with the same email ID already exists");
			
		}
		else if(out.equals("-4")) {
			JOptionPane.showMessageDialog(null, "A customer with the same phone number already exists");
			
		}
		
	}
}
