package UIModule;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import ExceptionHandling.ExceptionMaster;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;

public class ForgotPassPage extends JFrame {
	
	String connectionUrl = "jdbc:sqlserver://LAPTOP-9HEOT6R2\\SQLEXPRESS01;databaseName=StockManagement;user=Devansh;password=devansh21";
	Connection con;
	
	JLabel lblErrorMsg;
	
	ExceptionMaster obj = new ExceptionMaster();
	
	private JPanel contentPane;
	private JTextField txtEmail;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ForgotPassPage frame = new ForgotPassPage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ForgotPassPage() {
		
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			con = DriverManager.getConnection(connectionUrl);
			
			
		}
		catch(Exception ex) {
			obj.InsertException(ex.getMessage(), "ForgotPassPage", "Constructor");
			lblErrorMsg.setText(ex.getMessage());
			
		}
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(-5, 0, 1545, 870);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		lblErrorMsg = new JLabel("");
		
		lblErrorMsg.setFont(new Font("Calibri", Font.BOLD, 26));
		lblErrorMsg.setBounds(503, 142, 659, 48);
		contentPane.add(lblErrorMsg);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 0, 0, 0));
		panel.setBounds(542, 298, 440, 243);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Email-ID");
		lblNewLabel_1.setFont(new Font("Calibri", Font.BOLD, 20));
		lblNewLabel_1.setBounds(37, 108, 76, 34);
		panel.add(lblNewLabel_1);
		
		
		
		JLabel lblDisplay = new JLabel("Forgot Password");
		lblDisplay.setBounds(108, 27, 232, 48);
		panel.add(lblDisplay);
		lblDisplay.setFont(new Font("Calibri", Font.BOLD, 26));
		
		txtEmail = new JTextField();
		txtEmail.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				lblErrorMsg.setText("");
			}
		});
		txtEmail.setColumns(10);
		txtEmail.setBounds(123, 108, 270, 34);
		panel.add(txtEmail);
		
		JButton btnContinue = new JButton("Continue");
		btnContinue.addActionListener(new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
				String Pass = ValidateEmailDB(txtEmail.getText()) ;
				
				if(!Pass.equals("-1")) {
					lblErrorMsg.setText("Your old password is : "+ Pass);
				
				}
				else {
					lblErrorMsg.setText("The email you have entered is wrong. Please try again");
				}
				
				
			}
		});
		btnContinue.setBackground(new Color(211, 211, 211));
		btnContinue.setFont(new Font("Calibri", Font.BOLD, 20));
		btnContinue.setBounds(123, 174, 191, 34);
		panel.add(btnContinue);
		
		JLabel lblPanelBG = new JLabel("");
		lblPanelBG.setIcon(new ImageIcon("C:\\Users\\devan\\Downloads\\Green.jpg"));
		lblPanelBG.setBounds(-32, 0, 472, 243);
		panel.add(lblPanelBG);
		
		JLabel lblBG = new JLabel("");
		lblBG.setIcon(new ImageIcon("C:\\Users\\devan\\Pictures\\aqua BG.png"));
		lblBG.setBounds(0, 0, 1545, 870);
		contentPane.add(lblBG);

		
	}
	
	public String ValidateEmailDB(String EmailID) {
		String Output = "0";
		
		
		try {
			CallableStatement stmt = con.prepareCall("{call Proc_UserMaster_ValidateEmail(?)}");
			
			stmt.setString(1, EmailID);
			stmt.execute();
			
			ResultSet rs = stmt.getResultSet();
			while(rs.next()) {
				Output= rs.getString("Password");
				
			}
			
			
		}
		catch(Exception Ex) {
			obj.InsertException(Ex.getMessage(), "ForgotPassPage", "ValidateEmailDB");
			lblErrorMsg.setText(Ex.getMessage());
		}
		
		return Output;
	}
}
