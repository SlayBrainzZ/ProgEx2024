package UIModule;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import BusinessLayer.SalesReportBusiness;
import ExceptionHandling.ExceptionMaster;

import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import java.sql.*;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
public class DateWiseRevenueReport extends JFrame {
	ExceptionMaster obj = new ExceptionMaster();
	private JPanel contentPane;
	private JTable table;
	
	String connectionUrl = "jdbc:sqlserver://LAPTOP-9HEOT6R2\\SQLEXPRESS01;databaseName=StockManagement;user=Devansh;password=devansh21";
	Connection con;
	
	DefaultTableModel objTableModel = new DefaultTableModel();
	SalesReportBusiness objSales = new SalesReportBusiness();
	JTextField txtStartDate;
	JTextField txtEndDate;
	private JLabel lblNewLabel;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DateWiseRevenueReport frame = new DateWiseRevenueReport();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DateWiseRevenueReport() {
	
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(-5, 60, 1545, 800);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		objTableModel.addColumn("Date From");
		objTableModel.addColumn("Date To");
		objTableModel.addColumn("Revenue");
		
		
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(538, 338, 669, 266);
		contentPane.add(scrollPane);
		
		table = new JTable(objTableModel);
		scrollPane.setViewportView(table);
		
		txtStartDate = new JTextField();
		txtStartDate.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				if(txtStartDate.getText().equals("YYYY-MM-DD")) {
					txtStartDate.setText("");
				}
				
			}
		});
		
		txtStartDate.setText("YYYY-MM-DD");
		txtStartDate.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtStartDate.setBounds(81, 337, 140, 27);
		contentPane.add(txtStartDate);
		txtStartDate.setColumns(10);
		
		txtEndDate = new JTextField();
		txtEndDate.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(txtEndDate.getText().equals("YYYY-MM-DD")) {
					txtEndDate.setText("");
					
				}

			}
		});
		
		txtEndDate.setText("YYYY-MM-DD");
		txtEndDate.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtEndDate.setBounds(265, 337, 140, 27);
		contentPane.add(txtEndDate);
		txtEndDate.setColumns(10);
		
		JButton btnNewButton = new JButton("Calculate");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if( txtStartDate.equals("YYYY/MM/DD") || txtEndDate.getText().equals("YYYY/MM/DD") || txtStartDate.equals("") || txtEndDate.getText().equals("") ) {
					
					JOptionPane.showMessageDialog(null, "Please enter the date in the correct format");
					
				}
				
				
				getRevenue();
				
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton.setBounds(168, 424, 155, 33);
		contentPane.add(btnNewButton);
		
		lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(DateWiseRevenueReport.class.getResource("/BackgroundImage/aqua BG.png")));
		lblNewLabel.setBounds(0, 0, 1545, 800);
		contentPane.add(lblNewLabel);
		
		
	}
	
	public void getRevenue() {
		
		try {
			
			String StartDate = txtStartDate.getText();
			String EndDate = txtEndDate.getText();
			
			double Amt = objSales.GetAmount(StartDate, EndDate);
			
			objTableModel.setRowCount(0);
			
			objTableModel.insertRow(0, new Object[] {StartDate, EndDate, Amt} );
			
		}
		catch(Exception e) {
			JOptionPane.showMessageDialog(null, "Please enter the date in the given format");
		}
		
		

	}
	
	
	
}
