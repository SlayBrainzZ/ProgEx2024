package UIModule;

import java.awt.BorderLayout;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.Color;
import java.sql.*;
import javax.swing.border.MatteBorder;

import BusinessLayer.AccountBusiness;
import CommonInterface.CRUDInterface;
import ExceptionHandling.ExceptionMaster;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JComboBox;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import java.util.*;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.BevelBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.ImageIcon;
public class DeleteAccountMaster extends JFrame implements CRUDInterface {

	private JPanel contentPane;
	JLabel lblMsg;
	String out = "1";
	JComboBox cmbBoxCusName ;
	
	String CusNames[] = new String[] {};
	private JTextField txtBalAmt;
	private JTextField txtCity;
	private JTextField txtPhNum;
	private JTextField txtEmail;
	
	AccountBusiness objAcc = new AccountBusiness();
	ExceptionMaster obj = new ExceptionMaster();
	
	
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DeleteAccountMaster frame = new DeleteAccountMaster();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DeleteAccountMaster() {
		
		
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(-5, 70, 1545, 800);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(230, 230, 250));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		lblMsg = new JLabel("");
		lblMsg.setFont(new Font("Arial", Font.BOLD, 20));
		lblMsg.setBounds(62, 135, 1487, 32);
		contentPane.add(lblMsg);
		
		JPanel panel = new JPanel();
		panel.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		panel.setBackground(new Color(0, 191, 255));
		panel.setBounds(503, 200, 506, 389);
		contentPane.add(panel);
		panel.setLayout(null);
		
		
		
		JLabel lblNewLabel = new JLabel("Delete Account");
		lblNewLabel.setFont(new Font("Calibri", Font.BOLD, 26));
		lblNewLabel.setBounds(164, 10, 178, 42);
		panel.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Delete");
		btnNewButton.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Delete();
				
				
			}
		});
		btnNewButton.setVerticalAlignment(SwingConstants.TOP);
		btnNewButton.setFont(new Font("Calibri", Font.BOLD, 20));
		btnNewButton.setBounds(157, 332, 185, 28);
		panel.add(btnNewButton);
		
		JLabel lblNewLabel_1_1 = new JLabel("Customer Name");
		lblNewLabel_1_1.setFont(new Font("Calibri", Font.BOLD, 20));
		lblNewLabel_1_1.setBounds(64, 93, 153, 36);
		panel.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1 = new JLabel("Balance Amount");
		lblNewLabel_1.setFont(new Font("Calibri", Font.BOLD, 20));
		lblNewLabel_1.setBounds(64, 139, 162, 28);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("City");
		lblNewLabel_1_2.setFont(new Font("Calibri", Font.BOLD, 20));
		lblNewLabel_1_2.setBounds(66, 181, 162, 28);
		panel.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_2_1 = new JLabel("Phone Number");
		lblNewLabel_1_2_1.setFont(new Font("Calibri", Font.BOLD, 20));
		lblNewLabel_1_2_1.setBounds(66, 221, 162, 28);
		panel.add(lblNewLabel_1_2_1);
		
		JLabel lblNewLabel_1_2_2 = new JLabel("Email ID");
		lblNewLabel_1_2_2.setFont(new Font("Calibri", Font.BOLD, 20));
		lblNewLabel_1_2_2.setBounds(66, 262, 162, 28);
		panel.add(lblNewLabel_1_2_2);
		
		txtBalAmt = new JTextField();
		txtBalAmt.setText("0");
		txtBalAmt.setEditable(false);
		txtBalAmt.setColumns(10);
		txtBalAmt.setBounds(246, 139, 184, 28);
		panel.add(txtBalAmt);
		
		txtCity = new JTextField();
		txtCity.setEditable(false);
		txtCity.setColumns(10);
		txtCity.setBounds(248, 181, 184, 28);
		panel.add(txtCity);
		
		txtPhNum = new JTextField();
		txtPhNum.setEditable(false);
		txtPhNum.setColumns(10);
		txtPhNum.setBounds(248, 225, 184, 28);
		panel.add(txtPhNum);
		
		txtEmail = new JTextField();
		txtEmail.setEditable(false);
		txtEmail.setColumns(10);
		txtEmail.setBounds(248, 266, 184, 28);
		panel.add(txtEmail);
		
		cmbBoxCusName = new JComboBox();
		cmbBoxCusName.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String CusName = (String) cmbBoxCusName.getSelectedItem();
				Dictionary Values = objAcc.GetCustomerDetails(CusName); 
				txtEmail.setText( (String)Values.get("EmailID"));
				txtPhNum.setText((String) Values.get("Phone") );
				txtCity.setText((String) Values.get("City"));
			
			}
		});
		cmbBoxCusName.setBounds(244, 100, 188, 28);
		panel.add(cmbBoxCusName);
		
		JLabel lblBG = new JLabel("");
		lblBG.setIcon(new ImageIcon(DeleteAccountMaster.class.getResource("/BackgroundImage/Blue BG.png")));
		lblBG.setBounds(0, 0, 1545, 820);
		contentPane.add(lblBG);
		populateComboBox();
		
		
	}
	
	public void Insert() {
		
	}
	public void Update() {
		
	}
	public void Read() {
		
	}
	
	public void Delete() {
		
		String CusName = (String)cmbBoxCusName.getSelectedItem();
		objAcc.DeleteCustomerDB(CusName);
		JOptionPane.showMessageDialog(null, "Customer information was successfully deleted");
		

		populateComboBox();
		
		
	}
	
	public void populateComboBox() {
		
		cmbBoxCusName.removeAllItems();
		String[] CusNames = objAcc.GetCusNames_Delete();
		int ArrLength = CusNames.length;
		
		for(int i=0;i<ArrLength;i++) {
			cmbBoxCusName.addItem(CusNames[i]);

		}
	}
}
