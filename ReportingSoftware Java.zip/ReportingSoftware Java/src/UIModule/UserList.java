package UIModule;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import ExceptionHandling.ExceptionMaster;

import java.sql.*;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
public class UserList extends JFrame {
	
	ExceptionMaster obj = new ExceptionMaster();
	
	String connectionUrl = "jdbc:sqlserver://LAPTOP-9HEOT6R2\\SQLEXPRESS01;databaseName=StockManagement;user=Devansh;password=devansh21";
	Connection con;
	
	DefaultTableModel objTableModel;
	
	private JPanel contentPane;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UserList frame = new UserList();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public UserList() {
		
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			con = DriverManager.getConnection(connectionUrl);
			
			
		}
		catch(Exception ex) {
			obj.InsertException(ex.getMessage(), "UserList", "Constructor");
			
		}
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(-3, 70, 1545, 800);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		objTableModel = new DefaultTableModel();
		objTableModel.addColumn("ID");
		objTableModel.addColumn("Name");
		objTableModel.addColumn("Username");
		objTableModel.addColumn("Phone Number");
		objTableModel.addColumn("Email ID");
		objTableModel.addColumn("Address");
		
		getData();
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(340, 274, 764, 245);
		contentPane.add(scrollPane);
		
		table = new JTable(objTableModel);
		scrollPane.setViewportView(table);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(UserList.class.getResource("/BackgroundImage/aqua BG.png")));
		lblNewLabel.setBounds(0, 0, 1575, 875);
		contentPane.add(lblNewLabel);
		
	}
	
	public void getData() {
		
		try {
			
			CallableStatement stmt = con.prepareCall("{call Proc_UserMaster_Read}");
			
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()) {
				
				objTableModel.insertRow(0, new Object[] {rs.getInt("UserID"), rs.getString("Name"), rs.getString("Username"), rs.getString("Phone_Number"), rs.getString("Email_ID"), rs.getString("Address") } );
				
			}
			
			
		}
		catch(Exception e) {
			obj.InsertException(e.getMessage(), "UserList", "getData");
		}
		
	}
}
