package UIModule;

import java.awt.BorderLayout;


import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.LineBorder;

import BusinessLayer.SalesBusiness;
import CommonInterface.CRUDInterface;
import ExceptionHandling.ExceptionMaster;

import java.sql.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.AbstractButton;
import javax.swing.ImageIcon;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JComboBox; 

public class SalesMaster extends JFrame implements CRUDInterface{
	String connectionUrl = "jdbc:sqlserver://LAPTOP-9HEOT6R2\\SQLEXPRESS01;databaseName=StockManagement;user=Devansh;password=devansh21";
	Connection con;
	private JPanel contentPane;
	private JTextField txtQtty;
	private JTextField txtRate;
	private JTextField txtAmt;
	private JTextField txtDate;
	JLabel lblMsg;
	SalesBusiness objSales = new SalesBusiness();
	ExceptionMaster obj = new ExceptionMaster();
	
	JComboBox cmbBoxItemName;
	JComboBox cmbBoxCusName;
	String[] Items= new String[] {};
	String[] CusNames = new String[] {};
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SalesMaster frame = new SalesMaster();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SalesMaster() {
		
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			con = DriverManager.getConnection(connectionUrl);
			
			
		}
		catch(Exception ex) {
			obj.InsertException(ex.getMessage(), "SalesMaster", "Constructor");
			lblMsg.setText(ex.getMessage());
		}
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(-5, 60, 1545, 800);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel.setLayout(null);
		panel.setBackground(Color.WHITE);
		panel.setBounds(332, 191, 850, 417);
		contentPane.add(panel);
		
		cmbBoxItemName = new JComboBox();
		cmbBoxItemName.setBounds(206, 174, 169, 28);
		panel.add(cmbBoxItemName);
		
		cmbBoxCusName = new JComboBox();
		cmbBoxCusName.setBounds(206, 124, 169, 28);
		panel.add(cmbBoxCusName);
		
		
		JButton btnSubmit = new JButton("Submit");
		btnSubmit.setIcon(null);
		btnSubmit.setVerticalAlignment(SwingConstants.TOP);
		
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Insert();				
				
			}
		});
		btnSubmit.setFont(new Font("Calibri", Font.BOLD, 20));
		btnSubmit.setBackground(new Color(0, 206, 209));
		btnSubmit.setBounds(323, 358, 190, 30);
		panel.add(btnSubmit);
		
		JLabel lblSales = new JLabel("Sales ");
		lblSales.setFont(new Font("Calibri", Font.BOLD, 26));
		lblSales.setBounds(390, 20, 69, 29);
		panel.add(lblSales);
		
		JLabel lblNewLabel_1_3_1 = new JLabel("Customer name");
		lblNewLabel_1_3_1.setFont(new Font("Calibri", Font.BOLD, 20));
		lblNewLabel_1_3_1.setBounds(52, 128, 144, 23);
		panel.add(lblNewLabel_1_3_1);
		
		JLabel lblNewLabel_1_3_1_1 = new JLabel("Quantity");
		lblNewLabel_1_3_1_1.setFont(new Font("Calibri", Font.BOLD, 20));
		lblNewLabel_1_3_1_1.setBounds(52, 227, 101, 23);
		panel.add(lblNewLabel_1_3_1_1);
		
		JLabel lblNewLabel_1_3_1_2 = new JLabel("Rate");
		lblNewLabel_1_3_1_2.setFont(new Font("Calibri", Font.BOLD, 20));
		lblNewLabel_1_3_1_2.setBounds(52, 266, 101, 23);
		panel.add(lblNewLabel_1_3_1_2);
		
		JLabel lblNewLabel_1_3_1_2_1 = new JLabel("Amount");
		lblNewLabel_1_3_1_2_1.setFont(new Font("Calibri", Font.BOLD, 20));
		lblNewLabel_1_3_1_2_1.setBounds(472, 127, 101, 23);
		panel.add(lblNewLabel_1_3_1_2_1);
		
		txtQtty = new JTextField();
		txtQtty.setColumns(10);
		txtQtty.setBounds(206, 222, 169, 28);
		panel.add(txtQtty);
		
		txtRate = new JTextField();
		txtRate.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				String Qtty = txtQtty.getText();
				String Rate = txtRate.getText();
				
				if(!(Rate.isBlank() && Qtty.isBlank())) {
					GetAmount();
				}
				
			
				
			}
		});
		txtRate.setColumns(10);
		txtRate.setBounds(206, 261, 169, 28);
		panel.add(txtRate);
		
		txtAmt = new JTextField();
		txtAmt.setEditable(false);
		txtAmt.setColumns(10);
		txtAmt.setBounds(586, 124, 169, 28);
		panel.add(txtAmt);
		
		JLabel lblNewLabel_1_3_1_2_1_2 = new JLabel("Item Name");
		lblNewLabel_1_3_1_2_1_2.setFont(new Font("Calibri", Font.BOLD, 20));
		lblNewLabel_1_3_1_2_1_2.setBounds(52, 179, 108, 23);
		panel.add(lblNewLabel_1_3_1_2_1_2);
		
		JLabel lblNewLabel_1_3_1_2_2 = new JLabel("Date");
		lblNewLabel_1_3_1_2_2.setFont(new Font("Calibri", Font.BOLD, 20));
		lblNewLabel_1_3_1_2_2.setBounds(472, 178, 101, 23);
		panel.add(lblNewLabel_1_3_1_2_2);
		
		txtDate = new JTextField();
		txtDate.setText("YYYY-MM-DD");
		
		txtDate.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(txtDate.getText().equals("YYYY-MM-DD")) {
					txtDate.setText("");
				}
				
			}
		});
		txtDate.setFont(new Font("Calibri", Font.BOLD, 20));
		txtDate.setColumns(10);
		txtDate.setBounds(586, 175, 169, 28);
		panel.add(txtDate);
		
		JLabel lblPanelBG = new JLabel("");
		lblPanelBG.setIcon(new ImageIcon("C:\\Users\\devan\\Downloads\\GradBG1 (1).jpg"));
		lblPanelBG.setBounds(0, 0, 850, 417);
		panel.add(lblPanelBG);
		
		JLabel lblButtonBG = new JLabel("");
		lblButtonBG.setIcon(new ImageIcon("C:\\Users\\devan\\Downloads\\ButtonBG.jpg"));
		lblButtonBG.setBounds(323, 357, 203, 30);
		panel.add(lblButtonBG);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setBounds(584, 291, 45, 13);
		panel.add(lblNewLabel);
		
		lblMsg = new JLabel("");
		lblMsg.setBounds(332, 137, 850, 30);	
		contentPane.add(lblMsg);
		
		lblMsg.setForeground(Color.RED);
		lblMsg.setFont(new Font("Calibri", Font.BOLD, 25));
		
		JLabel lblBG = new JLabel("Submit");
		lblBG.setIcon(new ImageIcon("C:\\Users\\devan\\Downloads\\jbg2 (1).jpg"));
		lblBG.setBounds(-5, 0, 1545, 870);
		contentPane.add(lblBG);
		GetCusNamesInCmbBox();
		GetItemsInCmbBox();
		
	}
	
	public void Update() {
	}
	public void Delete() {
	}
	public void Read() {
	}
	
	public void Insert() {
		String CusName = (String) cmbBoxCusName.getSelectedItem();
		String Item = (String) cmbBoxItemName.getSelectedItem();
		String Qtty = txtQtty.getText() ;
		String Rate = txtRate.getText();
		String Date = txtDate.getText();
		

		if(Qtty.isBlank()) {

			JOptionPane.showMessageDialog(null,"Enter the quantity");
		}
		else if(Rate.isBlank()) {

			JOptionPane.showMessageDialog(null,"Enter the rate of the item sold");
		}
		else if(Date.isBlank()) {

			JOptionPane.showMessageDialog(null,"Enter the date");
		}

		else {

			objSales.InsertInDB(CusName, Qtty, Rate, Date, Item);
			JOptionPane.showMessageDialog(null,"Details entered successfully");
			
			txtQtty.setText("");
			txtRate.setText("");
			txtAmt.setText("");
			txtDate.setText("YYYY-MM-DD");
		}

	}
	
	
	
	public void GetItemsInCmbBox() {
		
		
		Items = objSales.GetItems_Insert();
		int ArrLen = Items.length;
		cmbBoxItemName.removeAllItems();
		
		for(int i=0;i<ArrLen;i++) {
			cmbBoxItemName.addItem(Items[i]);
		}
		
		
	}
	
	public void GetCusNamesInCmbBox() {
		CusNames = objSales.GetCusNames_Insert();
		int ArrLength = CusNames.length;
		
		cmbBoxCusName.removeAllItems();
			
			
		for(int i=0;i<ArrLength;i++) {
			cmbBoxCusName.addItem(CusNames[i]);
			
		}
	}

	
	public void GetAmount() {
		
		try {
			
			double Amt = 0.0;
			String Qtty = txtQtty.getText();
			String Rate = txtRate.getText();
			
			
			if(!(Qtty.isBlank() && Rate.isBlank())) {
				Amt = Integer.parseInt(Qtty) * Double.parseDouble(Rate);
				txtAmt.setText(Amt+ "");
			}
			else {
				txtAmt.setText("");
			}
			
		}
		catch(Exception ex) {
			obj.InsertException(ex.getMessage(), "SalesMaster", "GetAmount");
		}
		
	
	}
}
