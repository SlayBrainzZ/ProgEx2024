package UIModule;

import java.awt.BorderLayout;
import java.sql.*;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import BusinessLayer.CategoryBusiness;
import CommonInterface.CRUDInterface;
import ExceptionHandling.ExceptionMaster;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.ImageIcon;

public class DeleteCategory extends JFrame implements CRUDInterface {
	
	private JPanel contentPane;
	String Category[] = new String[] {};
	JComboBox comboBox;
	JLabel lblMsg;
	
	CategoryBusiness objCat = new CategoryBusiness();
	ExceptionMaster obj = new ExceptionMaster();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DeleteCategory frame = new DeleteCategory();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DeleteCategory() {
		
		
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(-5, 60, 1545, 800);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(new Color(102, 204, 255));
		panel.setBounds(551, 259, 425, 252);
		contentPane.add(panel);
		
		lblMsg = new JLabel("");
		lblMsg.setFont(new Font("Dubai", Font.BOLD, 20));
		lblMsg.setBounds(225, 214, 1400, 35);
		contentPane.add(lblMsg);
		
		comboBox = new JComboBox();
		
		comboBox.setBounds(180, 105, 198, 28);
		panel.add(comboBox);
		
		
		JButton btnNewButton = new JButton("Submit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Delete();
				
				
			}
		});
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setFont(new Font("Calibri", Font.BOLD, 20));
		btnNewButton.setBackground(Color.BLACK);
		btnNewButton.setBounds(110, 175, 190, 36);
		panel.add(btnNewButton);
		
		JLabel lblNewLabel_1_2 = new JLabel("Category name");
		lblNewLabel_1_2.setFont(new Font("Calibri", Font.BOLD, 20));
		lblNewLabel_1_2.setBounds(34, 104, 126, 32);
		panel.add(lblNewLabel_1_2);
		
		JLabel lblDeleteCategory = new JLabel("Delete category");
		lblDeleteCategory.setFont(new Font("Calibri", Font.BOLD, 26));
		lblDeleteCategory.setBounds(110, 10, 198, 38);
		panel.add(lblDeleteCategory);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\devan\\Downloads\\BG1.jpg"));
		lblNewLabel.setBounds(0, 0, 1545, 870);
		contentPane.add(lblNewLabel);
		populateComboBox();
		
	}
	
	public void Insert() {
	}
	public void Update(){
	}
	public void Read() {
	}
	
	public void Delete() {
		String CatName= (String) comboBox.getSelectedItem();
		objCat.DeleteCatDB(CatName);	
		comboBox.removeItem(CatName);
		JOptionPane.showMessageDialog(null, "Category successfully deleted");
		
		
	}
	
	
	
	public void populateComboBox() {
		
		Category = objCat.populateComboBox_Delete();
		int ArrLen = Category.length ;
		for(int i=0;i<ArrLen;i++) {
			comboBox.addItem(Category[i]);
		}
		
	}
}
