package UIModule;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import ExceptionHandling.ExceptionMaster;

import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.Color;
import java.sql.*;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
public class SalesList extends JFrame {
	
	String connectionUrl = "jdbc:sqlserver://LAPTOP-9HEOT6R2\\SQLEXPRESS01;databaseName=StockManagement;user=Devansh;password=devansh21";
	Connection con;

	private JPanel contentPane;
	private JTable table;
	DefaultTableModel objTableModel;
	
	//[][]
	
	ExceptionMaster objEx = new ExceptionMaster(); 
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SalesList frame = new SalesList();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SalesList() {
		
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			con = DriverManager.getConnection(connectionUrl);
			
			
		}
		catch(Exception ex) {
			objEx.InsertException(ex.getMessage(), "SalesList", "Constructor");
			
		}
		
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(-7, 60, 1545, 800);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		objTableModel = new DefaultTableModel();
		objTableModel.addColumn("Sales ID");
		objTableModel.addColumn("Customer Name");
		objTableModel.addColumn("Amount");
		objTableModel.addColumn("Date");
		objTableModel.addColumn("Item bought");
		objTableModel.addColumn("Quantity");
		objTableModel.addColumn("Rate");
		
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setFont(new Font("Tahoma", Font.PLAIN, 14));
		scrollPane.setBounds(356, 308, 776, 204);
		contentPane.add(scrollPane);
		
		table = new JTable(objTableModel);
		scrollPane.setViewportView(table);
		
		lblNewLabel = new JLabel("Sales List");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel.setBounds(633, 249, 106, 37);
		contentPane.add(lblNewLabel);
		
		lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon(SalesList.class.getResource("/BackgroundImage/aqua BG.png")));
		lblNewLabel_1.setBounds(0, 0, 1545, 803);
		contentPane.add(lblNewLabel_1);
		getDetails();
	}
	
	public void getDetails() {
		
		try {
			
			CallableStatement stmt = con.prepareCall("{call Proc_SalesMaster_Details}");
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()) {
				
				objTableModel.insertRow(0, new Object[] {rs.getInt("SalesID"), rs.getString("Name"), rs.getDouble("Amount"), rs.getString("TransactionDate"), rs.getString("Item_Name"), rs.getInt("Quantity"), rs.getDouble("Rate")} );
				
			}
			
		}
		catch(Exception ex) {
			objEx.InsertException(ex.getMessage(), "SalesList", "getDetails");
			ex.printStackTrace();
		}
		
		
		
	}
	
}
